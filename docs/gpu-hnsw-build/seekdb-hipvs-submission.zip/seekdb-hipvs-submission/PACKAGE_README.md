# seekdb hipVS 提交材料

先阅读 docs/gpu-hnsw-build/SUBMISSION.md 和 READINESS_AUDIT_20261031.md。
完整仓库：https://github.com/sevenmiles666/psfseekdb ，分支 competition/amd-hipvs-build。
本包是相关源码、文档、测试和验证记录，不是独立的完整工程，也不是 CPack 运行包。
完整构建请克隆仓库；源码快照提交号及文件校验见 PACKAGE_MANIFEST.json。
本轮已完成安装规则和嵌套并行设置的 Linux 本地测试，完整新 GPU 验证未完成。
云端安装遗漏观察、内核死亡报告、缓存准备失败与历史通过记录分别保存，不能混写为本轮通过。
competition-changes.patch 可在干净赛事基线使用 git apply --check 核对；不包含材料 ZIP 本身。
归档源于已提交 Git 内容，保留 Linux LF。历史源码哈希核验需要完整 Git 仓库及对应 --source-ref。
