# AMD hipVS 提交材料（2026-11-01）

先读 docs/gpu-hnsw-build/SUBMISSION.md 及 PACKAGING_AUDIT_20261101.md。
完整工程：https://github.com/sevenmiles666/psfseekdb ，分支 competition/amd-hipvs-build。

完整 GPU TGZ 编译提交：cfae4ba92b14d3010f7c7aa6a87d064dfd7c0075。
实际 CPack 与解包运行的数据修复提交：f18737e699ad0b29e38759fa821fec79e3940545。
两者仅相差从上游恢复的 tools/timezone_V1.log。最终提交另合并 5e35ceac 的 Farm/obtest 入口修复，
在 Linux 单独通过 17 项入口/部署回归；没有改编译的 C++、GPU 或 CMake 源码。文档、证据及材料包随后更新，未再次全量编译。
真实 CPack 两个 TGZ、27 项 SQL、CPU/GPU 各三轮、DML/过滤、隐藏 GPU 重启全部通过。
TGZ 验证显式设置 syslog_level=INFO 以采集 GPU 路径证据；未设置 LD_LIBRARY_PATH/LD_PRELOAD。
完整原始结果位于 results/radeon-20261101-package，官方成绩仍以平台回执为准。

本包含相关源码、测试、证据和相对赛事基线的二进制补丁；完整构建使用上面的完整仓库。
competition-changes.patch 已在赛事基线 5bce9e06d1281347ad61344e4b01fab9158c58a2 的独立 Git index 上执行 apply --check。
TGZ 运行包及第三方 hipVS/ROCm 库不包含在本材料 ZIP 中；包哈希记录在证据中。
SHA256 清单见 PACKAGE_MANIFEST.json；保留 Linux LF 换行。
