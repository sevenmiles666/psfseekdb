from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import subprocess
import tarfile
import traceback

ROOT = Path('/workspace/amd-repro-20261102')
SRC = ROOT / 'source-host'
EVIDENCE = ROOT / 'evidence'
SHA = 'f3cfe8b1738c2ce0d71a7cd04e8c2c69f6f938c1'
ARCHIVE_SHA = '95add40e722a8397376de8d1d80c8870a5c8f1e162b7d8728db16c8ebb1142fd'
stage = 'source-transport-verification'
prefix = ROOT / 'tooling/rust-1.98.1'
env = dict(os.environ)
env.update(PATH=str(prefix / 'bin') + ':/opt/venv/bin:/opt/rocm/bin:' + env.get('PATH', ''),
           RUSTC=str(prefix / 'bin/rustc'), RUSTUP_TOOLCHAIN='1.98.1',
           CARGO_HOME=str(ROOT / 'tooling/cargo-home'), CARGO_NET_OFFLINE='true',
           CARGO_BUILD_JOBS='1', OMP_NUM_THREADS='8', OPENBLAS_NUM_THREADS='8',
           GITHUB_WORKSPACE=str(SRC), SEEKDB_TASK_DIR=str(EVIDENCE / 'task'),
           PACKAGE_TYPE='tgz', MAKE_ARGS='-j4', SEEKDB_BUILD_HIPVS='ON')
env.pop('DEP_CACHE_DIR', None)
env.pop('LD_PRELOAD', None)
env.pop('LD_LIBRARY_PATH', None)


def digest(path):
    with Path(path).open('rb') as f:
        return hashlib.file_digest(f, 'sha256').hexdigest()


def status(state, **extra):
    report = dict(stage=stage, state=state, source_commit=SHA, cpp_jobs=4,
                  dependency_mode='verified offline Rust/crates; network RPM init',
                  source_transport='host shallow git clone uploaded after cloud GitHub TLS failure',
                  updated_utc=datetime.now(timezone.utc).isoformat(), **extra)
    (EVIDENCE / 'current-status.json').write_text(json.dumps(report, indent=2) + '\n')
    print(json.dumps(report), flush=True)


def run(args, label, timeout=10800):
    with (EVIDENCE / (label + '.log')).open('a') as output:
        output.write(json.dumps({'command': [str(a) for a in args]}) + '\n')
        output.flush()
        subprocess.run([str(a) for a in args], cwd=SRC, env=env, stdout=output,
                       stderr=subprocess.STDOUT, timeout=timeout, check=True)


try:
    status('running')
    assert json.loads((EVIDENCE / 'assets.json').read_text())['completed']
    archive = ROOT / 'incoming/source-git.tar.gz'
    assert digest(archive) == ARCHIVE_SHA
    assert not SRC.exists(), 'refuse to overwrite an existing source workspace'
    with tarfile.open(archive) as packed:
        packed.extractall(ROOT, filter='data')
    for key, value in [('core.autocrlf', 'false'), ('core.filemode', 'true'), ('core.symlinks', 'true')]:
        subprocess.run(['git', 'config', key, value], cwd=SRC, check=True)
    subprocess.run(['git', 'checkout', 'HEAD', '--', '.'], cwd=SRC, check=True)
    assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=SRC, text=True).strip() == SHA
    assert subprocess.check_output(['git', 'status', '--porcelain'], cwd=SRC, text=True) == ''
    names = subprocess.check_output(['git', 'ls-files', '-z'], cwd=SRC).decode().rstrip('\0').split('\0')
    hashes = {name: digest(SRC / name) for name in names}
    (EVIDENCE / 'source-sha256.json').write_text(json.dumps(hashes, indent=2))
    (EVIDENCE / 'source-transport.json').write_text(json.dumps(dict(
        commit=SHA, archive_sha256=ARCHIVE_SHA, tracked_files=len(hashes),
        original_cloud_clone_failed=True, credentials_used=False), indent=2))
    stage = 'offline-workspace-lock'
    status('running')
    run([prefix / 'bin/cargo', 'generate-lockfile', '--offline', '--manifest-path', SRC / 'rust/Cargo.toml'],
        'workspace-lock', timeout=120)
    stage = 'regressions'
    status('running')
    run(['/opt/venv/bin/python', '-m', 'unittest', 'discover', '-s', 'unittest/sql/vector_index',
         '-p', 'test_hipvs_*.py', '-v'], 'regressions', timeout=900)
    stage = 'real-contest-compile-entry'
    status('running')
    run(['bash', SRC / '.github/script/seekdb/compile.sh'], 'compile-entry')
    stage = 'generate-admin-and-build-all'
    status('running')
    run(['make', '-C', SRC / 'build_tgz', '-j2', 'generate_syspack_source'], 'generate-admin')
    run(['make', '-C', SRC / 'build_tgz', '-j2'], 'build-all')
    for name, value in hashes.items():
        assert digest(SRC / name) == value, name
    run(['git', 'diff', '--exit-code'], 'final-source-check', timeout=60)
    stage = 'build-passed'
    status('passed', tracked_files_unchanged=len(hashes))
except Exception as error:
    status('failed', error=repr(error))
    traceback.print_exc()
    raise
