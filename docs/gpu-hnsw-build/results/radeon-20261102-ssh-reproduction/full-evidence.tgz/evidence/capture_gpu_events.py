from pathlib import Path
import json,time,os
r=Path('/workspace/amd-repro-20261102/evidence');logs=Path('/var/tmp/amd-repro-20261102/log'); seen={}; events=set();deadline=time.monotonic()+1800
with (r/'gpu-events-live.log').open('a') as out:
 while time.monotonic()<deadline:
  for p in logs.glob('seekdb.log*'):
   try:
    st=p.stat();key=(st.st_dev,st.st_ino);offset=seen.get(key,0)
    if st.st_size<offset:offset=0
    with p.open('rb') as f:
     f.seek(offset)
     while True:
      line=f.readline()
      if not line:break
      if not line.endswith(b'\n'):f.seek(-len(line),1);break
      if b'[HIPVS_BUILD]' in line and line not in events:
       events.add(line);out.write(line.decode(errors='replace'));out.flush()
     seen[key]=f.tell()
   except (FileNotFoundError,OSError):pass
  try:
   status=json.loads((r/'package-status.json').read_text())
   if status.get('completed') or status.get('stage')=='failed':break
  except (FileNotFoundError,json.JSONDecodeError):pass
  time.sleep(0.2)
(r/'gpu-event-capture.json').write_text(json.dumps({'captured_lines':len(events),'scope':'raw HIPVS_BUILD lines observed while package acceptance ran; not a profiler trace'},indent=2))
