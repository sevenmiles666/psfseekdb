from pathlib import Path
import subprocess,tarfile,hashlib,json,time
r=Path('/workspace/amd-repro-20261102'); prefix=r/'tooling/rust-1.98.1'
report={'completed':False,'started_utc':time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()),'scope':'verified toolchain and vendored dependency cache'}
try:
 manifest=json.loads((r/'incoming/rust-packages.json').read_text())
 for item in manifest:
  a=r/'incoming'/item['file']
  assert a.stat().st_size==item['bytes']
  assert hashlib.file_digest(a.open('rb'),'sha256').hexdigest()==item['sha256'],str(a)
  target=r/'tooling/packages'/item['package'];target.mkdir(parents=True)
  with tarfile.open(a) as t:t.extractall(target,filter='data')
  installers=list(target.glob('*/install.sh'));assert len(installers)==1
  subprocess.run(['bash',str(installers[0]),'--prefix='+str(prefix),'--disable-ldconfig'],check=True)
  print('verified installed',item['package'],flush=True)
 cache=r/'tooling/crate-archives';cache.mkdir(parents=True)
 with tarfile.open(r/'incoming/offline-crates.tar') as t:t.extractall(cache,filter='data')
 packages=json.loads((cache/'crate-manifest.json').read_text())
 vendor=r/'tooling/vendor';vendor.mkdir(parents=True)
 for item in packages:
  a=cache/item['filename'];assert hashlib.file_digest(a.open('rb'),'sha256').hexdigest()==item['sha256']
  with tarfile.open(a) as t:t.extractall(vendor,filter='data')
  p=vendor/(item['name']+'-'+item['version'])
  files={f.relative_to(p).as_posix():hashlib.file_digest(f.open('rb'),'sha256').hexdigest() for f in p.rglob('*') if f.is_file() and f.name!='.cargo-checksum.json'}
  (p/'.cargo-checksum.json').write_text(json.dumps({'package':item['sha256'],'files':files}))
 home=r/'tooling/cargo-home';home.mkdir()
 (home/'config.toml').write_text('[source.crates-io]\nreplace-with="vendored-sources"\n[source.vendored-sources]\ndirectory="'+str(vendor)+'"\n[net]\noffline=true\n')
 report['packages']=packages;report['toolchain']=manifest
 for name in ['cargo','rustc']:
  report[name]=subprocess.check_output([str(prefix/'bin'/name),'--version'],text=True).strip()
 report['completed']=True
except Exception as e:
 report['error']=str(e);raise
finally:
 report['finished_utc']=time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime())
 (r/'evidence/assets.json').write_text(json.dumps(report,indent=2))
