from pathlib import Path
import json
import math
from statistics import median
import subprocess
import sys

root=Path('/workspace/amd-v5-round2')
source=(root/'release-selected/seekdb_cuvs_bridge.c').read_text()
configs=[('iter192',192,'ITERATIVE_CAGRA_SEARCH',0),('iter256',256,'ITERATIVE_CAGRA_SEARCH',0),
         ('pq64',192,'IVF_PQ',64),('pq128',192,'IVF_PQ',128)]
reports=[]
for name,inter,algo,probes in configs:
    label='r3-'+name;dest=root/label;dest.mkdir(exist_ok=False)
    code=source.replace('intermediate_graph_degree = 192;',f'intermediate_graph_degree = {inter};').replace('build_algo = NN_DESCENT;',f'build_algo = {algo};')
    if probes:
        old='  if (cuvsCagraBuild(h->res, h->ip, &dset, h->idx) != CUVS_SUCCESS) goto fail_idx;'
        new='''  {
    struct cuvsIvfPqParams pq;
    if (cuvsIvfPqIndexParamsCreate(&pq.ivf_pq_build_params) != CUVS_SUCCESS) goto fail_idx;
    if (cuvsIvfPqSearchParamsCreate(&pq.ivf_pq_search_params) != CUVS_SUCCESS) {
      cuvsIvfPqIndexParamsDestroy(pq.ivf_pq_build_params); goto fail_idx;
    }
    pq.ivf_pq_build_params->n_lists = 256;
    pq.ivf_pq_build_params->pq_dim = (uint32_t)dim / 2;
    pq.ivf_pq_search_params->n_probes = PROBES;
    pq.refinement_rate = 4.0f;
    h->ip->graph_build_params = &pq;
    cuvsError_t status = cuvsCagraBuild(h->res, h->ip, &dset, h->idx);
    h->ip->graph_build_params = NULL;
    cuvsIvfPqSearchParamsDestroy(pq.ivf_pq_search_params);
    cuvsIvfPqIndexParamsDestroy(pq.ivf_pq_build_params);
    if (status != CUVS_SUCCESS) goto fail_idx;
  }'''.replace('PROBES',str(probes))
        assert old in code;code=code.replace(old,new)
    (dest/'seekdb_cuvs_bridge.c').write_text(code)
    for f in ('seekdb_cuvs_bridge.h','build.sh'):(dest/f).write_bytes((root/'release-selected'/f).read_bytes())
    lib=dest/'libseekdb_cuvs_bridge.so'
    subprocess.run(['bash',str(dest/'build.sh'),str(lib)],check=True)
    for kind in ('gaussian256','sift250k','clustered256'):
        with (root/'evidence'/f'{kind}-{label}.log').open('w') as log:
            rc=subprocess.run([sys.executable,str(root/'benchmark_bridge.py'),'--work-dir',str(root),'--dataset',kind,'--label',label,'--lib',str(lib),'--rounds','1'],stdout=log,stderr=subprocess.STDOUT).returncode
        row=dict(label=label,dataset=kind,rc=rc)
        if not rc:
            a=json.loads((root/'evidence'/f'{kind}-final-baseline.json').read_text());b=json.loads((root/'evidence'/f'{kind}-{label}.json').read_text())
            row['recall']={};qs=[]
            for k in ('10','100'):
                threshold=max(.95 if kind=='sift250k' else (.90 if k=='10' else .85),max(r['topk'][k]['recall'] for r in a['rounds'])-.005)
                recall=b['rounds'][0]['topk'][k]['recall'];row['recall'][k]=dict(value=recall,threshold=threshold,passed=recall>=threshold)
                qs.append(b['rounds'][0]['topk'][k]['median_qps']/median(r['topk'][k]['median_qps'] for r in a['rounds']))
            row['query_ratio']=math.sqrt(math.prod(qs));row['build_ratio']=median(r['build_plus_first_query_seconds'] for r in a['rounds'])/b['rounds'][0]['build_plus_first_query_seconds']
            row['vram_ratio']=b['peak_vram_device_bytes']/a['peak_vram_device_bytes']
            row['passed']=all(x['passed'] for x in row['recall'].values()) and row['query_ratio']>=.9 and row['vram_ratio']<=1.25
        reports.append(row);(root/'round3-algorithms-summary.json').write_text(json.dumps(reports,indent=2));print(json.dumps(row),flush=True)
        if rc or not row['passed']:break
print('ALGORITHMS_COMPLETED',flush=True)
