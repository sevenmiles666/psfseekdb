from pathlib import Path
import json
import math
from statistics import median
import subprocess
import sys

root = Path('/workspace/amd-v5-round2')
source = (root / 'release-selected/seekdb_cuvs_bridge.c').read_text()
configs = [(192,128,50,8), (192,128,32,8), (128,128,32,8),
           (128,96,32,8), (128,64,32,8), (128,128,20,16)]
reports = []
for inter, degree, iterations, samples in configs:
    label = f'r3-i{inter}-g{degree}-n{iterations}-s{samples}'
    dest = root / label
    dest.mkdir(exist_ok=False)
    code = source.replace('intermediate_graph_degree = 192;', f'intermediate_graph_degree = {inter};')
    code = code.replace('graph_degree = 128;', f'graph_degree = {degree};')
    code = code.replace('nn_descent_niter = 64;', f'nn_descent_niter = {iterations};')
    code = code.replace('num_random_samplings = 4;', f'num_random_samplings = {samples};')
    (dest / 'seekdb_cuvs_bridge.c').write_text(code)
    for name in ('seekdb_cuvs_bridge.h', 'build.sh'):
        (dest / name).write_bytes((root / 'release-selected' / name).read_bytes())
    lib = dest / 'libseekdb_cuvs_bridge.so'
    subprocess.run(['bash', str(dest / 'build.sh'), str(lib)], check=True)
    for kind in ('gaussian256', 'sift250k', 'clustered256'):
        with (root / 'evidence' / f'{kind}-{label}.log').open('w') as log:
            rc = subprocess.run([sys.executable, str(root / 'benchmark_bridge.py'), '--work-dir', str(root),
                                 '--dataset', kind, '--label', label, '--lib', str(lib), '--rounds', '1'],
                                stdout=log, stderr=subprocess.STDOUT).returncode
        row = dict(label=label, dataset=kind, rc=rc)
        if not rc:
            a = json.loads((root / 'evidence' / f'{kind}-final-baseline.json').read_text())
            b = json.loads((root / 'evidence' / f'{kind}-{label}.json').read_text())
            row['recall'] = {}
            ratios = []
            for k in ('10','100'):
                threshold = max(.95 if kind=='sift250k' else (.90 if k=='10' else .85), max(r['topk'][k]['recall'] for r in a['rounds'])-.005)
                recall = b['rounds'][0]['topk'][k]['recall']
                row['recall'][k] = dict(value=recall, threshold=threshold, passed=recall>=threshold)
                ratios.append(b['rounds'][0]['topk'][k]['median_qps']/median(r['topk'][k]['median_qps'] for r in a['rounds']))
            row['query_ratio'] = math.sqrt(math.prod(ratios))
            row['build_ratio'] = median(r['build_plus_first_query_seconds'] for r in a['rounds']) / b['rounds'][0]['build_plus_first_query_seconds']
            row['vram_ratio'] = b['peak_vram_device_bytes']/a['peak_vram_device_bytes']
            row['passed'] = all(x['passed'] for x in row['recall'].values()) and row['query_ratio']>=.9 and row['vram_ratio']<=1.25
        reports.append(row)
        (root / 'round3-screen-summary.json').write_text(json.dumps(reports, indent=2))
        print(json.dumps(row), flush=True)
        if rc or not row['passed']:
            break
print('SCREEN_COMPLETED', flush=True)
