from pathlib import Path
import json
import math
from statistics import median
import subprocess
import sys
import time

root=Path('/workspace/amd-v5-round2')
for _ in range(240):
    if 'SEARCH_COMPLETED' in (root/'round3-search.log').read_text():break
    time.sleep(2)
else:raise RuntimeError('Previous search experiment still active')
seed=root/'seed20261103'
lib=root/'r3-n50-t8-b0/libseekdb_cuvs_bridge.so'
with (seed/'round3-50.log').open('w') as log:
    subprocess.run([sys.executable,str(seed/'benchmark_seed20261103.py'),'--work-dir',str(seed),'--dataset','gaussian256','--label','r3-n50-t8-b0','--lib',str(lib),'--rounds','3'],stdout=log,stderr=subprocess.STDOUT,check=True,timeout=180)
a=json.loads((seed/'evidence/gaussian256-frozen-100-w4.json').read_text());b=json.loads((seed/'evidence/gaussian256-r3-n50-t8-b0.json').read_text())
seed_report={}
for k in ('10','100'):
    threshold=max(.9 if k=='10' else .85,max(r['topk'][k]['recall'] for r in a['rounds'])-.005)
    worst=min(r['topk'][k]['recall'] for r in b['rounds']);seed_report[k]=dict(worst=worst,threshold=threshold,passed=worst>=threshold,margin=worst-threshold)
(root/'round3-independent-seed.json').write_text(json.dumps(seed_report,indent=2));print('INDEPENDENT_SEED',json.dumps(seed_report),flush=True)
source=(root/'r3-pq64/seekdb_cuvs_bridge.c').read_text()
reports=[]
for probes in (8,16):
    label=f'r3-pq-fast{probes}';dest=root/label;dest.mkdir(exist_ok=False)
    code=source.replace('n_probes = 64;',f'n_probes = {probes};').replace('pq.refinement_rate = 4.0f;','pq.refinement_rate = 2.0f;')
    code=code.replace('pq.ivf_pq_build_params->n_lists = 256;', 'pq.ivf_pq_build_params->n_lists = 256;\n    pq.ivf_pq_build_params->kmeans_n_iters = 5;\n    pq.ivf_pq_build_params->kmeans_trainset_fraction = 0.1;')
    (dest/'seekdb_cuvs_bridge.c').write_text(code)
    for f in ('seekdb_cuvs_bridge.h','build.sh'):(dest/f).write_bytes((root/'release-selected'/f).read_bytes())
    lib=dest/'libseekdb_cuvs_bridge.so';subprocess.run(['bash',str(dest/'build.sh'),str(lib)],check=True)
    with (root/'evidence'/f'gaussian256-{label}.log').open('w') as log:
        rc=subprocess.run([sys.executable,str(root/'benchmark_bridge.py'),'--work-dir',str(root),'--dataset','gaussian256','--label',label,'--lib',str(lib),'--rounds','2'],stdout=log,stderr=subprocess.STDOUT,timeout=180).returncode
    row=dict(label=label,rc=rc)
    if not rc:
        a=json.loads((root/'evidence/gaussian256-final-baseline.json').read_text());b=json.loads((root/'evidence'/f'gaussian256-{label}.json').read_text())
        row['recall']={};qs=[]
        for k in ('10','100'):
            threshold=max(.90 if k=='10' else .85,max(r['topk'][k]['recall'] for r in a['rounds'])-.005)
            recall=min(r['topk'][k]['recall'] for r in b['rounds']);row['recall'][k]=dict(value=recall,threshold=threshold,passed=recall>=threshold)
            qs.append(median(r['topk'][k]['median_qps'] for r in b['rounds'])/median(r['topk'][k]['median_qps'] for r in a['rounds']))
        row['query_ratio']=math.sqrt(math.prod(qs));row['build_ratio']=median(r['build_plus_first_query_seconds'] for r in a['rounds'])/median(r['build_plus_first_query_seconds'] for r in b['rounds'])
        row['vram_ratio']=b['peak_vram_device_bytes']/a['peak_vram_device_bytes'];row['passed']=all(x['passed'] for x in row['recall'].values()) and row['query_ratio']>=.9 and row['vram_ratio']<=1.25
    reports.append(row);(root/'round3-final-probe-summary.json').write_text(json.dumps(reports,indent=2));print(json.dumps(row),flush=True)
print('FINAL_PROBE_COMPLETED',flush=True)
