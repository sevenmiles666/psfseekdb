from pathlib import Path
import json
import math
from statistics import median
import subprocess
import sys
import time

root=Path('/workspace/amd-v5-round2')
for _ in range(180):
    if 'ALGORITHMS_COMPLETED' in (root/'round3-algorithms.log').read_text():break
    time.sleep(2)
else:raise RuntimeError('Previous GPU experiment did not complete; refusing concurrent benchmark')
source=(root/'release-selected/seekdb_cuvs_bridge.c').read_text()
configs=[(50,8,0),(50,16,0),(50,32,0),(50,8,256),(64,8,0),(64,16,0)]
reports=[]
for iterations,team,block in configs:
    label=f'r3-n{iterations}-t{team}-b{block}'
    dest=root/label;dest.mkdir(exist_ok=False)
    code=source.replace('nn_descent_niter = 64;',f'nn_descent_niter = {iterations};')
    code=code.replace('sp->search_width = 32;',f'sp->search_width = 32;\n      sp->team_size = {team};\n      sp->thread_block_size = {block};')
    (dest/'seekdb_cuvs_bridge.c').write_text(code)
    for f in ('seekdb_cuvs_bridge.h','build.sh'):(dest/f).write_bytes((root/'release-selected'/f).read_bytes())
    lib=dest/'libseekdb_cuvs_bridge.so';subprocess.run(['bash',str(dest/'build.sh'),str(lib)],check=True)
    for kind in ('gaussian256','sift250k','clustered256'):
        with (root/'evidence'/f'{kind}-{label}.log').open('w') as log:
            rc=subprocess.run([sys.executable,str(root/'benchmark_bridge.py'),'--work-dir',str(root),'--dataset',kind,'--label',label,'--lib',str(lib),'--rounds','2'],stdout=log,stderr=subprocess.STDOUT,timeout=180).returncode
        row=dict(label=label,dataset=kind,rc=rc)
        if not rc:
            a=json.loads((root/'evidence'/f'{kind}-final-baseline.json').read_text());b=json.loads((root/'evidence'/f'{kind}-{label}.json').read_text())
            row['recall']={};qs=[]
            for k in ('10','100'):
                threshold=max(.95 if kind=='sift250k' else (.90 if k=='10' else .85),max(r['topk'][k]['recall'] for r in a['rounds'])-.005)
                recall=min(r['topk'][k]['recall'] for r in b['rounds']);row['recall'][k]=dict(value=recall,threshold=threshold,passed=recall>=threshold)
                qs.append(median(r['topk'][k]['median_qps'] for r in b['rounds'])/median(r['topk'][k]['median_qps'] for r in a['rounds']))
            row['query_ratio']=math.sqrt(math.prod(qs));row['build_ratio']=median(r['build_plus_first_query_seconds'] for r in a['rounds'])/median(r['build_plus_first_query_seconds'] for r in b['rounds'])
            row['vram_ratio']=b['peak_vram_device_bytes']/a['peak_vram_device_bytes'];row['passed']=all(x['passed'] for x in row['recall'].values()) and row['query_ratio']>=.9 and row['vram_ratio']<=1.25
        reports.append(row);(root/'round3-search-summary.json').write_text(json.dumps(reports,indent=2));print(json.dumps(row),flush=True)
        if rc or not row['passed']:break
print('SEARCH_COMPLETED',flush=True)
