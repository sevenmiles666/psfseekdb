#!/bin/bash
set -euo pipefail
cd /workspace/amd-v5-round2
for ((i=0; i<240; i++)); do
  if grep -q REFINED_FINISHED refined.log; then
    export LD_LIBRARY_PATH=/opt/hipvs/lib:/opt/rocm/lib
    exec /opt/venv/bin/python confirm_candidates.py
  fi
  state=$(ps -p 12158 -o stat= || true)
  if [[ -z "$state" || "$state" == Z* ]]; then
    echo 'Refined experiments stopped before their completion marker' >&2
    exit 1
  fi
  sleep 5
done
echo 'Timed out waiting for refined experiments' >&2
exit 1
