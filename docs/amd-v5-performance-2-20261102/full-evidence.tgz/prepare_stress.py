"""Prepare another independent Gaussian seed, using the identical exact-L2 checker."""
from pathlib import Path
import subprocess
import sys

root = Path('/workspace/amd-v5-round2')
stress = root / 'seed20261103'
stress.mkdir(exist_ok=False)
source = (root / 'benchmark_bridge.py').read_text()
assert source.count('default_rng(20261102)') == 1
bench = stress / 'benchmark_seed20261103.py'
bench.write_text(source.replace('default_rng(20261102)', 'default_rng(20261103)'))
subprocess.run([sys.executable, str(bench), '--work-dir', str(stress), '--prepare', 'gaussian256'], check=True)
