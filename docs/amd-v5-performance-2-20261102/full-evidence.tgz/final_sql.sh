#!/bin/bash
set -euo pipefail
cd /workspace/amd-v5-round2
export LD_LIBRARY_PATH=/opt/hipvs/lib:/opt/rocm/lib
export OPENBLAS_NUM_THREADS=8 OMP_NUM_THREADS=8
binary="$PWD/source/build_release/src/observer/seekdb"
for item in 'final-baseline:frozen-100-w4' 'final-scored:scored-80-w16' 'final-selected:final-selected' \
            'round2-selected:final-selected' 'round2-scored:scored-80-w16' 'round2-baseline:frozen-100-w4' \
            'round3-scored:scored-80-w16' 'round3-baseline:frozen-100-w4' 'round3-selected:final-selected'; do
  label=${item%%:*}; library=${item#*:}
  /opt/venv/bin/python benchmark_sql.py --work-dir "$PWD" --binary "$binary" \
    --bridge "$PWD/$library/libseekdb_cuvs_bridge.so" --label "$label" --port 2902 --nq 256 > "evidence/sql-$label.log" 2>&1
  echo "FINAL_SQL_PASSED $label"
done
/opt/venv/bin/python compare_results.py --evidence "$PWD/evidence" \
  --sql-pair round2-baseline round2-selected --sql-pair round3-baseline round3-selected \
  --output "$PWD/evidence/paired-summary.json" > evidence/comparison.log
echo FINAL_VALIDATION_FINISHED
