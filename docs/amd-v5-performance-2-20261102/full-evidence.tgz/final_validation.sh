#!/bin/bash
set -euo pipefail
cd /workspace/amd-v5-round2
export LD_LIBRARY_PATH=/opt/hipvs/lib:/opt/rocm/lib
export OPENBLAS_NUM_THREADS=8 OMP_NUM_THREADS=8
for ((i=0; i<180; i++)); do
  if grep -q FULL_V5_BUILD_COMPLETED build-resume.log; then break; fi
  state=$(ps -p 16353 -o stat= || true)
  if [[ -z "$state" || "$state" == Z* ]]; then echo 'Build failed' >&2; exit 1; fi
  sleep 5
done
grep -q FULL_V5_BUILD_COMPLETED build-resume.log
grep -q CONFIRM_FINISHED confirmation.log
nm -D --defined-only frozen-100-w4/libseekdb_cuvs_bridge.so | awk '{print $3}' | sort > evidence/baseline-exports.txt
nm -D --defined-only final-selected/libseekdb_cuvs_bridge.so | awk '{print $3}' | sort > evidence/candidate-exports.txt
diff -u evidence/baseline-exports.txt evidence/candidate-exports.txt
/opt/rocm/bin/hipcc -O2 -Isource/tools/hipvs_bridge source/tools/hipvs_bridge/test_persistence.cpp \
  -Lfinal-selected -lseekdb_cuvs_bridge -o final-selected/test-persistence
LD_LIBRARY_PATH="$PWD/final-selected:$LD_LIBRARY_PATH" final-selected/test-persistence write "$PWD/final-selected/test.cagra" > evidence/persistence.log 2>&1
LD_LIBRARY_PATH="$PWD/final-selected:$LD_LIBRARY_PATH" final-selected/test-persistence read "$PWD/final-selected/test.cagra" >> evidence/persistence.log 2>&1
for kind in sift10k sift250k gaussian256 clustered256; do
  /opt/venv/bin/python benchmark_bridge.py --work-dir "$PWD" --dataset "$kind" --label final-baseline --lib "$PWD/frozen-100-w4/libseekdb_cuvs_bridge.so" --rounds 3 > "evidence/$kind-final-baseline.log" 2>&1
  /opt/venv/bin/python benchmark_bridge.py --work-dir "$PWD" --dataset "$kind" --label final-selected --lib "$PWD/final-selected/libseekdb_cuvs_bridge.so" --rounds 3 > "evidence/$kind-final-selected.log" 2>&1
  echo "FINAL_BRIDGE_PASSED $kind"
done
binary="$PWD/source/build_release/src/observer/seekdb"
# Rotate order across independent databases, rather than always timing the candidate last.
for item in 'final-baseline:frozen-100-w4' 'final-scored:scored-80-w16' 'final-selected:final-selected' \
            'round2-selected:final-selected' 'round2-scored:scored-80-w16' 'round2-baseline:frozen-100-w4' \
            'round3-scored:scored-80-w16' 'round3-baseline:frozen-100-w4' 'round3-selected:final-selected'; do
  label=${item%%:*}; library=${item#*:}
  /opt/venv/bin/python benchmark_sql.py --work-dir "$PWD" --binary "$binary" \
    --bridge "$PWD/$library/libseekdb_cuvs_bridge.so" --label "$label" --port 2902 --nq 256 > "evidence/sql-$label.log" 2>&1
  echo "FINAL_SQL_PASSED $label"
done
/opt/venv/bin/python compare_results.py --evidence "$PWD/evidence" \
  --sql-pair round2-baseline round2-selected --sql-pair round3-baseline round3-selected \
  --output "$PWD/evidence/paired-summary.json" > evidence/comparison.log
echo FINAL_VALIDATION_FINISHED
