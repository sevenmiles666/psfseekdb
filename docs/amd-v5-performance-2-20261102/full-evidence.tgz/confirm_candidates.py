"""Shortlist development candidates, then check a second independent Gaussian seed.
This is not the official scoring harness and does not publish code.
"""
import json
import math
from pathlib import Path
from statistics import median
import subprocess
import sys

root = Path('/workspace/amd-v5-round2')
records = {}
for path in (root / 'evidence').glob('*.json'):
    row = json.loads(path.read_text())
    if row.get('completed') and 'rounds' in row:
        records[(row['dataset']['name'], row['label'])] = row
candidates = []
for label in sorted({label for _, label in records if label.startswith('trial-')}):
    details = []
    for kind in ('gaussian256', 'sift250k', 'clustered256'):
        base = records[(kind, 'frozen-100-w4')]
        row = records.get((kind, label))
        if row is None:
            break
        margins = []
        ratios = []
        for k in ('10', '100'):
            floor = .95 if kind == 'sift250k' else (.90 if k == '10' else .85)
            threshold = max(floor, max(r['topk'][k]['recall'] for r in base['rounds']) - .005)
            margins.append(min(r['topk'][k]['recall'] for r in row['rounds']) - threshold)
            ratios.append(median(r['topk'][k]['median_qps'] for r in row['rounds']) /
                          median(r['topk'][k]['median_qps'] for r in base['rounds']))
        q = math.sqrt(math.prod(ratios))
        vram_ratio = row['peak_vram_device_bytes'] / base['peak_vram_device_bytes']
        b = median(r['build_plus_first_query_seconds'] for r in base['rounds']) / median(r['build_plus_first_query_seconds'] for r in row['rounds'])
        # Additional local safety margin for the difficult synthetic dataset.
        passed = min(margins) >= (.0015 if kind == 'gaussian256' else 0) and q >= .9 and vram_ratio <= 1.25
        details.append(dict(dataset=kind, build_speed=b, query_speed=q, recall_margins=margins,
                            vram_ratio=vram_ratio, passed=passed))
    if len(details) != 3 or not all(d['passed'] for d in details):
        continue
    g, s = details[:2]
    b = s['build_speed'] ** .4 * g['build_speed'] ** .6
    q = s['query_speed'] ** .4 * g['query_speed'] ** .6
    objective = 14 * max(0, math.log(b) / math.log(3)) + 2 * max(0, math.log(q) / math.log(1.5))
    candidates.append(dict(label=label, development_objective=objective, datasets=details))
candidates.sort(key=lambda row: row['development_objective'], reverse=True)
shortlist = candidates[:2]
target = root / 'shortlist.json'
target.write_text(json.dumps({'scope': 'C ABI development heuristic only; not official SQL timings or score',
                              'candidates': candidates, 'shortlist': shortlist}, indent=2))
print(target.read_text(), flush=True)
assert shortlist, 'No candidates retain the requested quality margin'
stress = root / 'seed20261103'
for label in ['frozen-100-w4', 'scored-80-w16'] + [r['label'] for r in shortlist]:
    with (stress / (label + '.log')).open('w') as log:
        subprocess.run([sys.executable, str(stress / 'benchmark_seed20261103.py'), '--work-dir', str(stress),
                        '--dataset', 'gaussian256', '--label', label,
                        '--lib', str(root / label / 'libseekdb_cuvs_bridge.so'), '--rounds', '3'],
                       stdout=log, stderr=subprocess.STDOUT, check=True)
    print('STRESS_COMPLETED', label, flush=True)
print('CONFIRM_FINISHED', flush=True)
