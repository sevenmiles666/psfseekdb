#!/bin/bash
set -euo pipefail
cd /workspace/amd-v5-round2
export LD_LIBRARY_PATH=/opt/hipvs/lib:/opt/rocm/lib
export OPENBLAS_NUM_THREADS=8 OMP_NUM_THREADS=8
mkdir -p data evidence
for kind in gaussian256 clustered256; do
  /opt/venv/bin/python benchmark_bridge.py --work-dir "$PWD" --prepare "$kind"
done
while [ ! -f sift_query.fvecs ] || [ "$(stat -c %s sift_query.fvecs)" != 5160000 ] || [ "$(stat -c %s sift250k.fvecs)" != 129000000 ]; do sleep 2; done
ln -s ../sift250k.fvecs data/sift_base.fvecs
ln -s ../sift_query.fvecs data/sift_query.fvecs
/opt/venv/bin/python benchmark_bridge.py --work-dir "$PWD" --prepare sift250k
ls /seekdb_workspace/datasets
for label in frozen-100-w4 scored-80-w16 trial-80-w32 trial-64-w16 trial-64-w32 trial-50-w16 trial-50-w32; do
  bash "$label/build.sh" "$PWD/$label/libseekdb_cuvs_bridge.so"
  for kind in gaussian256 sift250k clustered256; do
    /opt/venv/bin/python benchmark_bridge.py --work-dir "$PWD" --dataset "$kind" --label "$label" --lib "$PWD/$label/libseekdb_cuvs_bridge.so" --rounds 3 > "evidence/$kind-$label.log" 2>&1 || { echo "REJECTED $kind $label"; break; }
  done
  echo "FINISHED $label"
done
echo ROUND2_FINISHED
