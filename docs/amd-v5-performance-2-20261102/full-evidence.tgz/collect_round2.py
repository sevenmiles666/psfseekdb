from pathlib import Path
import hashlib
import json
from statistics import median
import subprocess
import tarfile
import time

root = Path('/workspace/amd-v5-round2')
ev = root / 'evidence'
assert 'FINAL_VALIDATION_FINISHED' in (root / 'final-sql.log').read_text()
summary = json.loads((ev / 'paired-summary.json').read_text())
assert summary['passed']
scored = [json.loads((ev / ('sql-' + label + '.json')).read_text())
          for label in ('final-scored', 'round2-scored', 'round3-scored')]
selected = [json.loads((ev / ('sql-' + label + '.json')).read_text())
            for label in ('final-selected', 'round2-selected', 'round3-selected')]
assert all(r['completed'] and r['loaded_bridge_verified'] and r['cpu_vsag_passed'] and r['reload_validated'] for r in scored + selected)
comparison = []
for kind in ('sift250k', 'gaussian256'):
    a = [next(d for d in r['datasets'] if d['name'] == kind)['ddl_plus_first_query_seconds'] for r in scored]
    b = [next(d for d in r['datasets'] if d['name'] == kind)['ddl_plus_first_query_seconds'] for r in selected]
    comparison.append(dict(dataset=kind, scored_seconds=a, selected_seconds=b,
                           scored_median=median(a), selected_median=median(b),
                           speedup_over_scored=median(a) / median(b)))
(ev / 'compared-with-scored.json').write_text(json.dumps(comparison, indent=2))

def digest(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()

files = [root / 'final-selected/seekdb_cuvs_bridge.c', root / 'final-selected/libseekdb_cuvs_bridge.so',
         root / 'frozen-100-w4/libseekdb_cuvs_bridge.so', root / 'scored-80-w16/libseekdb_cuvs_bridge.so',
         root / 'source/build_release/src/observer/seekdb', root / 'benchmark_bridge.py', root / 'benchmark_sql.py']
metadata = dict(completed=True, utc=time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime()),
                frozen_commit='634888d9b037153fa143d2c913ba4b25503e1d62',
                scored_commit='f224065668dbf09bbfd24154321637235cf79baf',
                main_source_commit=subprocess.check_output(['git', '-C', str(root / 'source'), 'rev-parse', 'HEAD'], text=True).strip(),
                scope='public/generated paired GPU development validation; not official Hidden data or score',
                sha256={p.relative_to(root).as_posix(): digest(p) for p in files},
                memory_events=Path('/sys/fs/cgroup/memory.events').read_text())
subprocess.run(['git', '-C', str(root / 'source'), 'diff', '--exit-code'], check=True)
(ev / 'execution.json').write_text(json.dumps(metadata, indent=2))

# Include metrics/logs, final returned IDs, independent seed records and exact
# experimental source/driver files; exclude DSOs, snapshots, databases and vectors.
paths = set()
for directory in (ev, root / 'seed20261103/evidence'):
    for path in directory.iterdir():
        if path.suffix in ('.json', '.log', '.txt') or (path.suffix == '.npy' and ('-final-' in path.name or directory != ev)):
            paths.add(path)
for path in root.glob('*'):
    if path.is_file() and path.suffix in ('.py', '.sh', '.json', '.log'):
        paths.add(path)
    elif path.is_dir() and (path.name.startswith(('frozen-', 'scored-', 'trial-')) or path.name == 'final-selected'):
        paths.update(p for p in path.iterdir() if p.suffix in ('.c', '.h', '.sh'))
paths.add(root / 'seed20261103/benchmark_seed20261103.py')
paths.update((root / 'seed20261103').glob('*.log'))
for directory in (root / 'data').iterdir():
    if directory.is_dir():
        paths.add(directory / 'dataset.json')
paths.add(root / 'seed20261103/data/gaussian256/dataset.json')
target = root / 'full-evidence.tgz'
with tarfile.open(target, 'w:gz') as archive:
    for path in sorted(paths):
        archive.add(path, arcname=path.relative_to(root).as_posix(), recursive=False)
print(json.dumps({'evidence_bytes': target.stat().st_size, 'evidence_sha256': digest(target),
                  'compared_with_scored': comparison, 'execution': metadata}, indent=2))
