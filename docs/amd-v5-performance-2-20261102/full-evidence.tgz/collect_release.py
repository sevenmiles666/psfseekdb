from pathlib import Path
import hashlib
import json
import math
from statistics import median
import subprocess
import tarfile
import time

root = Path('/workspace/amd-v5-round2')
ev = root / 'evidence'
assert 'RELEASE_VALIDATION_FINISHED' in (root / 'release-validation.log').read_text()
summary = json.loads((ev / 'release-summary.json').read_text())
assert summary['passed']
seed_ev = root / 'seed20261103/evidence'
seed_base = json.loads((seed_ev / 'gaussian256-frozen-100-w4.json').read_text())
seed_selected = json.loads((seed_ev / 'gaussian256-release-selected.json').read_text())
assert seed_base['completed'] and seed_selected['completed']
assert seed_base['dataset'] == seed_selected['dataset']
seed_check = {'scope': 'independent generated seed 20261103, not official Hidden', 'recall': {}}
qratios = []
for k in ('10', '100'):
    floor = .90 if k == '10' else .85
    threshold = max(floor, max(r['topk'][k]['recall'] for r in seed_base['rounds']) - .005)
    value = min(r['topk'][k]['recall'] for r in seed_selected['rounds'])
    seed_check['recall'][k] = dict(candidate_worst=value, threshold=threshold, passed=value >= threshold)
    assert value >= threshold
    qratios.append(median(r['topk'][k]['median_qps'] for r in seed_selected['rounds']) / median(r['topk'][k]['median_qps'] for r in seed_base['rounds']))
seed_check['query_ratio'] = math.sqrt(math.prod(qratios))
seed_check['vram_ratio'] = seed_selected['peak_vram_device_bytes'] / seed_base['peak_vram_device_bytes']
assert seed_check['query_ratio'] >= .90 and seed_check['vram_ratio'] <= 1.25
assert seed_selected['peak_vram_device_bytes'] <= 45_000_000_000 and seed_selected['peak_rss_bytes'] <= 96_000_000_000
seed_check['passed'] = True
(ev / 'independent-seed-summary.json').write_text(json.dumps(seed_check, indent=2))
scored = [json.loads((ev / ('sql-' + label + '.json')).read_text())
          for label in ('final-scored', 'round2-scored', 'round3-scored')]
selected = [json.loads((ev / ('sql-' + label + '.json')).read_text())
            for label in ('release-selected', 'release2-selected', 'release3-selected')]
assert all(r['completed'] and r['loaded_bridge_verified'] and r['cpu_vsag_passed'] and r['reload_validated'] for r in scored + selected)
comparison = []
for kind in ('sift250k', 'gaussian256'):
    a = [next(d for d in r['datasets'] if d['name'] == kind)['ddl_plus_first_query_seconds'] for r in scored]
    b = [next(d for d in r['datasets'] if d['name'] == kind)['ddl_plus_first_query_seconds'] for r in selected]
    comparison.append(dict(dataset=kind, scored_seconds=a, selected_seconds=b,
                           scored_median=median(a), selected_median=median(b),
                           speedup_over_scored=median(a) / median(b)))
(ev / 'compared-with-scored.json').write_text(json.dumps(comparison, indent=2))

def digest(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()

files = [root / 'release-selected/seekdb_cuvs_bridge.c', root / 'release-selected/libseekdb_cuvs_bridge.so',
         root / 'frozen-100-w4/libseekdb_cuvs_bridge.so', root / 'scored-80-w16/libseekdb_cuvs_bridge.so',
         root / 'source/build_release/src/observer/seekdb', root / 'benchmark_bridge.py', root / 'benchmark_sql.py']
metadata = dict(completed=True, utc=time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime()),
                frozen_commit='634888d9b037153fa143d2c913ba4b25503e1d62',
                scored_commit='f224065668dbf09bbfd24154321637235cf79baf',
                main_source_commit=subprocess.check_output(['git', '-C', str(root / 'source'), 'rev-parse', 'HEAD'], text=True).strip(),
                scope='public/generated paired GPU development validation; not official Hidden data or score',
                sha256={p.relative_to(root).as_posix(): digest(p) for p in files},
                memory_events=Path('/sys/fs/cgroup/memory.events').read_text())
subprocess.run(['git', '-C', str(root / 'source'), 'diff', '--exit-code'], check=True)
(ev / 'execution.json').write_text(json.dumps(metadata, indent=2))

# Include metrics/logs, final returned IDs, independent seed records and exact
# experimental source/driver files; exclude DSOs, snapshots, databases and vectors.
paths = set()
for directory in (ev, root / 'seed20261103/evidence'):
    for path in directory.iterdir():
        raw_labels = ('-final-baseline-', '-release-selected-') if directory == ev else ('-frozen-100-w4-', '-release-selected-')
        if path.suffix in ('.json', '.log', '.txt') or (path.suffix == '.npy' and any(label in path.name for label in raw_labels)):
            paths.add(path)
for path in root.glob('*'):
    if path.is_file() and path.suffix in ('.py', '.sh', '.json', '.log') and path.name != 'collection.json':
        paths.add(path)
    elif path.is_dir() and (path.name.startswith(('frozen-', 'scored-', 'trial-')) or path.name in ('final-selected', 'release-selected', 'quality-random2', 'quality-random4')):
        paths.update(p for p in path.iterdir() if p.suffix in ('.c', '.h', '.sh'))
paths.add(root / 'seed20261103/benchmark_seed20261103.py')
paths.update((root / 'seed20261103').glob('*.log'))
for directory in (root / 'data').iterdir():
    if directory.is_dir():
        paths.add(directory / 'dataset.json')
paths.add(root / 'seed20261103/data/gaussian256/dataset.json')
target = root / 'full-evidence.tgz'
with tarfile.open(target, 'w:gz') as archive:
    for path in sorted(paths):
        archive.add(path, arcname=path.relative_to(root).as_posix(), recursive=False)
print(json.dumps({'evidence_bytes': target.stat().st_size, 'evidence_sha256': digest(target),
                  'compared_with_scored': comparison, 'execution': metadata}, indent=2))
