"""Isolated graph-build experiments, launched after the first parameter sweep."""
from pathlib import Path
import subprocess
import sys

root = Path('/workspace/amd-v5-round2')
source = (root / 'scored-80-w16/seekdb_cuvs_bridge.c').read_text()
profiles = [('trial-64-w64', 256, 64, 'NN_DESCENT', 64),
            ('trial-50-w64', 256, 50, 'NN_DESCENT', 64),
            ('trial-50-w128', 256, 50, 'NN_DESCENT', 128),
            ('trial-32-w128', 256, 32, 'NN_DESCENT', 128),
            ('trial-i192-n100', 192, 100, 'NN_DESCENT', 16),
            ('trial-i192-n80', 192, 80, 'NN_DESCENT', 16),
            ('trial-i160-n100', 160, 100, 'NN_DESCENT', 16),
            ('trial-ivfpq', 256, 80, 'IVF_PQ', 16)]
for label, intermediate, iterations, algo, width in profiles:
    dest = root / label
    dest.mkdir(exist_ok=False)
    code = source.replace('intermediate_graph_degree = 256;', f'intermediate_graph_degree = {intermediate};')
    code = code.replace('nn_descent_niter = 80;', f'nn_descent_niter = {iterations};')
    code = code.replace('build_algo = NN_DESCENT;', f'build_algo = {algo};')
    code = code.replace('sp->search_width = 16;', f'sp->search_width = {width};')
    (dest / 'seekdb_cuvs_bridge.c').write_text(code)
    for name in ('seekdb_cuvs_bridge.h', 'build.sh'):
        (dest / name).write_bytes((root / 'scored-80-w16' / name).read_bytes())
    lib = dest / 'libseekdb_cuvs_bridge.so'
    subprocess.run(['bash', str(dest / 'build.sh'), str(lib)], check=True)
    for kind in ('gaussian256', 'sift250k', 'clustered256'):
        with (root / 'evidence' / (kind + '-' + label + '.log')).open('w') as log:
            rc = subprocess.run([sys.executable, str(root / 'benchmark_bridge.py'), '--work-dir', str(root),
                                 '--dataset', kind, '--label', label, '--lib', str(lib), '--rounds', '2'],
                                stdout=log, stderr=subprocess.STDOUT).returncode
        print(label, kind, rc, flush=True)
        if rc:
            break
