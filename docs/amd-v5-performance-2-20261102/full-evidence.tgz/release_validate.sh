#!/bin/bash
set -euo pipefail
cd /workspace/amd-v5-round2
export LD_LIBRARY_PATH=/opt/hipvs/lib:/opt/rocm/lib OPENBLAS_NUM_THREADS=8 OMP_NUM_THREADS=8
mkdir -p release-selected
cp final-selected/{seekdb_cuvs_bridge.h,build.sh} release-selected/
/opt/venv/bin/python -c 'from pathlib import Path;p=Path("release-selected/seekdb_cuvs_bridge.c");p.write_bytes(p.read_bytes().replace(b"\r\n",b"\n"))'
bash release-selected/build.sh "$PWD/release-selected/libseekdb_cuvs_bridge.so"
nm -D --defined-only release-selected/libseekdb_cuvs_bridge.so | awk '{print $3}' | sort > evidence/release-exports.txt
diff -u evidence/baseline-exports.txt evidence/release-exports.txt
/opt/rocm/bin/hipcc -O2 -Isource/tools/hipvs_bridge source/tools/hipvs_bridge/test_persistence.cpp -Lrelease-selected -lseekdb_cuvs_bridge -o release-selected/test-persistence
LD_LIBRARY_PATH="$PWD/release-selected:$LD_LIBRARY_PATH" release-selected/test-persistence write "$PWD/release-selected/test.cagra" > evidence/release-persistence.log 2>&1
LD_LIBRARY_PATH="$PWD/release-selected:$LD_LIBRARY_PATH" release-selected/test-persistence read "$PWD/release-selected/test.cagra" >> evidence/release-persistence.log 2>&1
for kind in sift10k sift250k gaussian256 clustered256; do
  /opt/venv/bin/python benchmark_bridge.py --work-dir "$PWD" --dataset "$kind" --label release-selected --lib "$PWD/release-selected/libseekdb_cuvs_bridge.so" --rounds 3 > "evidence/$kind-release-selected.log" 2>&1
  echo "RELEASE_BRIDGE_PASSED $kind"
done
/opt/venv/bin/python seed20261103/benchmark_seed20261103.py --work-dir "$PWD/seed20261103" --dataset gaussian256 --label release-selected --lib "$PWD/release-selected/libseekdb_cuvs_bridge.so" --rounds 3 > seed20261103/release-selected.log 2>&1
for label in release-selected release2-selected release3-selected; do
  /opt/venv/bin/python benchmark_sql.py --work-dir "$PWD" --binary "$PWD/source/build_release/src/observer/seekdb" --bridge "$PWD/release-selected/libseekdb_cuvs_bridge.so" --label "$label" --port 2902 --nq 256 > "evidence/sql-$label.log" 2>&1
  echo "RELEASE_SQL_PASSED $label"
done
/opt/venv/bin/python compare_results.py --evidence "$PWD/evidence" --candidate release-selected --sql-pair round2-baseline release2-selected --sql-pair round3-baseline release3-selected --output "$PWD/evidence/release-summary.json" > evidence/release-comparison.log
echo RELEASE_VALIDATION_FINISHED
