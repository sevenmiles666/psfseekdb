import json
from pathlib import Path
from statistics import median
import math

root = Path('/workspace/amd-v5-round2/evidence')
records = {}
for path in root.glob('*.json'):
    record = json.loads(path.read_text())
    if record.get('completed') and 'rounds' in record:
        records[(record['dataset']['name'], record['label'])] = record
rows = []
for (kind, label), record in sorted(records.items()):
    baseline = records.get((kind, 'frozen-100-w4'))
    if baseline is None:
        continue
    assert baseline['dataset'] == record['dataset']
    worst = {k: min(r['topk'][k]['recall'] for r in record['rounds']) for k in ('10', '100')}
    thresholds = {k: max(.95 if kind == 'sift250k' else (.9 if k == '10' else .85),
                         max(r['topk'][k]['recall'] for r in baseline['rounds']) - .005) for k in ('10', '100')}
    qratio = math.sqrt(math.prod(median(r['topk'][k]['median_qps'] for r in record['rounds']) /
                                 median(r['topk'][k]['median_qps'] for r in baseline['rounds']) for k in ('10', '100')))
    speed = median(r['build_plus_first_query_seconds'] for r in baseline['rounds']) / median(r['build_plus_first_query_seconds'] for r in record['rounds'])
    rows.append(dict(dataset=kind, label=label, rounds=len(record['rounds']), build_speed=speed,
                     query_speed=qratio, worst_recall=worst, thresholds=thresholds,
                     quality_passed=all(worst[k] >= thresholds[k] for k in worst),
                     query_passed=qratio >= .9, vram_ratio=record['peak_vram_device_bytes'] / baseline['peak_vram_device_bytes']))
print(json.dumps(rows, indent=2))
