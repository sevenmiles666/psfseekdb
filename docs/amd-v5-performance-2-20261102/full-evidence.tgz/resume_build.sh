#!/bin/bash
set -euo pipefail
cd /workspace/amd-v5-round2/source
# The restored development archive contained an ignored, zero-byte generated file.
# Regenerate it with the frozen V5 generator and canonical header; no tracked edits.
bash src/sql/parser/gen_type_name.sh src/query/api/query/parser/ob_item_type.h > src/sql/parser/type_name.c
test -s src/sql/parser/type_name.c
export PATH=/opt/venv/bin:/opt/rocm/bin:/usr/local/bin:/usr/bin:/bin
export CARGO_HOME=/workspace/amd-v5-round2/tooling/cargo-home
export CARGO_NET_OFFLINE=true CARGO_BUILD_JOBS=1
bash build.sh release -DOB_BUILD_CUVS=ON -DOB_BUILD_CUVS_TRACE=OFF \
  -DCUVS_BRIDGE_LIB=/workspace/amd-v5-round2/frozen-100-w4/libseekdb_cuvs_bridge.so --make -j4
git diff --exit-code
echo FULL_V5_BUILD_COMPLETED
