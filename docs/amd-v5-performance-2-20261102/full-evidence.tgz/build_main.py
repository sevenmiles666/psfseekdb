"""Restore the unchanged frozen V5 SQL executable on a fresh GPU worker."""
from pathlib import Path
import concurrent.futures
import hashlib
import json
import os
import subprocess
import tarfile
import tomllib
import urllib.request

ROOT = Path('/workspace/amd-v5-round2')
SRC = ROOT / 'source'
TOOL = ROOT / 'tooling'
TOOL.mkdir(exist_ok=True)

def download(url, dest):
    if not dest.exists():
        with urllib.request.urlopen(url, timeout=120) as src, dest.open('wb') as out:
            while chunk := src.read(1 << 20):
                out.write(chunk)
    return dest

def rpm(line):
    name = line.split()[0]
    if name.startswith('obshell-'):
        return  # Optional packaging tool unavailable; core SQL build only.
    repo = 'community/stable' if 'target=community' in line else 'development-kit'
    path = download(f'https://mirrors.oceanbase.com/oceanbase/{repo}/el/8/x86_64/{name}', TOOL / name)
    return path

manifest = SRC / 'deps/init/oceanbase.el8.x86_64.deps'
lines = [l.strip() for l in manifest.read_text().splitlines() if l.strip() and not l.strip().startswith('#') and '.rpm' in l]
with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:
    archives = list(pool.map(rpm, lines))
deps = TOOL / '3rd'
deps.mkdir(exist_ok=True)
for archive in archives:
    if archive:
        subprocess.run(['/opt/venv/bin/python', str(ROOT / 'extract_rpm.py'), str(archive), str(deps)], check=True)
if not (SRC / 'deps/3rd').exists():
    (SRC / 'deps/3rd').symlink_to(deps, target_is_directory=True)
(deps / 'DONE').touch()
(deps / hashlib.md5(manifest.read_bytes()).hexdigest()).touch()
vendor = TOOL / 'vendor'
vendor.mkdir(exist_ok=True)
for pkg in tomllib.loads((SRC / 'rust/Cargo.lock').read_text())['package']:
    if not pkg.get('source', '').startswith('registry+'):
        continue
    name = pkg['name'] + '-' + pkg['version']
    path = download('https://static.crates.io/crates/' + pkg['name'] + '/' + name + '.crate', TOOL / (name + '.crate'))
    assert hashlib.sha256(path.read_bytes()).hexdigest() == pkg['checksum']
    with tarfile.open(path) as arc:
        arc.extractall(vendor, filter='data')
    package = vendor / name
    files = {p.relative_to(package).as_posix(): hashlib.sha256(p.read_bytes()).hexdigest()
             for p in package.rglob('*') if p.is_file() and p.name != '.cargo-checksum.json'}
    (package / '.cargo-checksum.json').write_text(json.dumps({'package': pkg['checksum'], 'files': files}))
home = TOOL / 'cargo-home'
home.mkdir(exist_ok=True)
(home / 'config.toml').write_text('[source.crates-io]\nreplace-with="vendor"\n[source.vendor]\ndirectory="' + str(vendor) + '"\n[net]\noffline=true\n')
env = dict(os.environ, CARGO_HOME=str(home), CARGO_NET_OFFLINE='true', CARGO_BUILD_JOBS='1',
           PATH='/opt/venv/bin:/opt/rocm/bin:/usr/local/bin:/usr/bin:/bin')
bridge = ROOT / 'frozen-100-w4/libseekdb_cuvs_bridge.so'
subprocess.run(['bash', 'build.sh', 'release', '-DOB_BUILD_CUVS=ON', '-DOB_BUILD_CUVS_TRACE=OFF',
                '-DCUVS_BRIDGE_LIB=' + str(bridge), '--make', '-j4'], cwd=SRC, env=env, check=True)
subprocess.run(['git', 'diff', '--exit-code'], cwd=SRC, check=True)
print('FULL_V5_BUILD_COMPLETED', flush=True)
