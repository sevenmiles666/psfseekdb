from pathlib import Path
import subprocess
import sys

root = Path('/workspace/amd-v5-round2')
source = (root / 'final-selected/seekdb_cuvs_bridge.c').read_text()
for samples in (2, 4):
    label = f'quality-random{samples}'
    dest = root / label
    dest.mkdir(exist_ok=False)
    code = source.replace('sp->search_width = 32;', f'sp->search_width = 32;\n      sp->num_random_samplings = {samples};')
    (dest / 'seekdb_cuvs_bridge.c').write_text(code)
    for name in ('seekdb_cuvs_bridge.h', 'build.sh'):
        (dest / name).write_bytes((root / 'final-selected' / name).read_bytes())
    lib = dest / 'libseekdb_cuvs_bridge.so'
    subprocess.run(['bash', str(dest / 'build.sh'), str(lib)], check=True)
    for kind in ('gaussian256', 'sift250k'):
        with (root / 'evidence' / (kind + '-' + label + '.log')).open('w') as log:
            subprocess.run([sys.executable, str(root / 'benchmark_bridge.py'), '--work-dir', str(root),
                            '--dataset', kind, '--label', label, '--lib', str(lib), '--rounds', '2'],
                           stdout=log, stderr=subprocess.STDOUT, check=True)
    with (root / 'evidence' / ('sql-' + label + '.log')).open('w') as log:
        subprocess.run([sys.executable, str(root / 'benchmark_sql.py'), '--work-dir', str(root),
                        '--binary', str(root / 'source/build_release/src/observer/seekdb'),
                        '--bridge', str(lib), '--label', label, '--port', '2902', '--nq', '256'],
                       stdout=log, stderr=subprocess.STDOUT, check=True)
    print('QUALITY_COMPLETED', label, flush=True)
