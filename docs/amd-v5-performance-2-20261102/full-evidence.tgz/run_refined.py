"""Combine smaller intermediate graphs with the supported width-32 search."""
from pathlib import Path
import subprocess
import sys

root = Path('/workspace/amd-v5-round2')
source = (root / 'scored-80-w16/seekdb_cuvs_bridge.c').read_text()
for intermediate, iterations in ((192, 64), (192, 50), (160, 64), (160, 50)):
    label = f'trial-i{intermediate}-n{iterations}-w32'
    dest = root / label
    dest.mkdir(exist_ok=False)
    code = source.replace('intermediate_graph_degree = 256;', f'intermediate_graph_degree = {intermediate};')
    code = code.replace('nn_descent_niter = 80;', f'nn_descent_niter = {iterations};')
    code = code.replace('sp->search_width = 16;', 'sp->search_width = 32;')
    (dest / 'seekdb_cuvs_bridge.c').write_text(code)
    for name in ('seekdb_cuvs_bridge.h', 'build.sh'):
        (dest / name).write_bytes((root / 'scored-80-w16' / name).read_bytes())
    lib = dest / 'libseekdb_cuvs_bridge.so'
    subprocess.run(['bash', str(dest / 'build.sh'), str(lib)], check=True)
    for kind in ('gaussian256', 'sift250k', 'clustered256'):
        with (root / 'evidence' / (kind + '-' + label + '.log')).open('w') as log:
            rc = subprocess.run([sys.executable, str(root / 'benchmark_bridge.py'), '--work-dir', str(root),
                                 '--dataset', kind, '--label', label, '--lib', str(lib), '--rounds', '2'],
                                stdout=log, stderr=subprocess.STDOUT).returncode
        print(label, kind, rc, flush=True)
        if rc:
            break
print('REFINED_FINISHED', flush=True)
