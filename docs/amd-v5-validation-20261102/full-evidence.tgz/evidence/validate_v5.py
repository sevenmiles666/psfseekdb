from pathlib import Path
import hashlib
import json
import os
import subprocess
import tarfile
import time
import tomllib
import traceback
import urllib.request
import urllib.error

ROOT = Path('/workspace/amd-v5-repair-20261102')
SRC = ROOT / 'source'
EV = ROOT / 'evidence'
OLD = Path('/workspace/amd-repro-20261102')
stage = 'prepare-frozen-dependencies'
env = dict(os.environ)
env.update(PATH='/opt/venv/bin:/opt/rocm/bin:/usr/local/bin:/usr/bin:/bin',
           CARGO_HOME=str(ROOT / 'tooling/cargo-home'), CARGO_NET_OFFLINE='true',
           CARGO_BUILD_JOBS='1', RUSTUP_TOOLCHAIN='1.97.1',
           OMP_NUM_THREADS='8', OPENBLAS_NUM_THREADS='8')
report = dict(completed=False, source_commit='d4840ee3ea658250810883a63b299b428290d3c0',
              frozen_base='634888d9b037153fa143d2c913ba4b25503e1d62',
              product_changes_from_base=False, performance_optimization=False)


def digest(path):
    with path.open('rb') as f:
        return hashlib.file_digest(f, 'sha256').hexdigest()


def save():
    report.update(stage=stage, updated_utc=time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime()))
    (EV / 'validation-status.json').write_text(json.dumps(report, indent=2))
    print(json.dumps({'stage':stage, 'completed':report['completed']}), flush=True)


def run(name, args, timeout=7200):
    with (EV / (name+'.log')).open('w') as f:
        f.write(json.dumps({'command':[str(a) for a in args]})+'\n');f.flush()
        result = subprocess.run([str(a) for a in args], cwd=SRC, env=env,
                                stdout=f, stderr=subprocess.STDOUT, timeout=timeout)
    result.check_returncode()


def download(url, target, expected=None):
    if not target.exists():
        print('download', url, flush=True)
        with urllib.request.urlopen(url, timeout=120) as stream, target.open('wb') as out:
            while chunk := stream.read(1024*1024):
                out.write(chunk)
    sha = digest(target)
    if expected is not None:
        assert sha == expected, target.name
    return sha


try:
    save()
    assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=SRC,text=True).strip()==report['source_commit']
    run('ancestry-check', ['bash','script/check_amd_v5.sh'], timeout=60)
    for name in ['cargo','rustc']:
        version=subprocess.check_output([name,'--version'],env=env,text=True).strip()
        assert '1.97.1 ' in version, version
        report[name]=version
    # Prepare exactly the V5 RPM manifest outside product source. The prior
    # initializer's libarchive extractor is used only as a provisioning tool.
    depfile=SRC/'deps/init/oceanbase.el8.x86_64.deps'
    deps=ROOT/'tooling/3rd';deps.mkdir(parents=True, exist_ok=True)
    rpmcache=ROOT/'tooling/rpms';rpmcache.mkdir(exist_ok=True)
    pkg_records=[]
    for line in depfile.read_text().splitlines():
        line=line.strip()
        if not line or line.startswith(('#','[')) or '.rpm' not in line: continue
        filename=line.split()[0]
        cached=OLD/'source-host/deps/3rd/pkg'/filename
        if cached.exists():
            archive=cached;sha=digest(archive);source='previous downloaded same-version RPM'
        else:
            repo='community/stable' if 'target=community' in line else 'development-kit'
            url=f'https://mirrors.oceanbase.com/oceanbase/{repo}/el/8/x86_64/{filename}'
            archive=rpmcache/filename
            try:
                sha=download(url,archive)
            except urllib.error.HTTPError as error:
                if filename.startswith('obshell-') and error.code==404:
                    report['unavailable_optional_package']={'name':filename,'url':url,'http_status':404,'scope':'not needed by core Release build; full packaging not validated'}
                    continue
                raise
            source=url
        run('extract-'+filename, ['/opt/venv/bin/python',OLD/'source-host/deps/init/extract_rpm.py',archive,deps], timeout=240)
        pkg_records.append({'name':filename,'sha256':sha,'source':source})
    report['dependency_manifest_md5']=hashlib.md5(depfile.read_bytes()).hexdigest()
    report['rpm_packages']=pkg_records
    (deps/'DONE').touch();(deps/report['dependency_manifest_md5']).touch()
    
    if not (SRC/'deps/3rd').exists():
        (SRC/'deps/3rd').symlink_to(deps, target_is_directory=True)
    stage='prepare-locked-cargo';save()
    vendor=ROOT/'tooling/vendor';vendor.mkdir(exist_ok=True)
    cratecache=ROOT/'tooling/crates';cratecache.mkdir(exist_ok=True)
    lock=tomllib.loads((SRC/'rust/Cargo.lock').read_text())
    crate_records=[]
    for pkg in lock['package']:
        if not pkg.get('source','').startswith('registry+'):continue
        filename=pkg['name']+'-'+pkg['version']+'.crate'
        cached=OLD/'tooling/crate-archives'/filename
        if cached.exists() and digest(cached)==pkg['checksum']:
            archive=cached
        else:
            archive=cratecache/filename
            download('https://static.crates.io/crates/'+pkg['name']+'/'+filename,archive,pkg['checksum'])
        with tarfile.open(archive) as packed:packed.extractall(vendor,filter='data')
        package=vendor/(pkg['name']+'-'+pkg['version'])
        files={f.relative_to(package).as_posix():digest(f) for f in package.rglob('*')
               if f.is_file() and f.name!='.cargo-checksum.json'}
        (package/'.cargo-checksum.json').write_text(json.dumps({'package':pkg['checksum'],'files':files}))
        crate_records.append({'name':pkg['name'],'version':pkg['version'],'sha256':pkg['checksum']})
    report['locked_cargo_packages']=crate_records
    home=ROOT/'tooling/cargo-home';home.mkdir(exist_ok=True)
    (home/'config.toml').write_text('[source.crates-io]\nreplace-with="vendor"\n[source.vendor]\ndirectory="'+str(vendor)+'"\n[net]\noffline=true\n')
    stage='official-bridge-build';save()
    bridge=ROOT/'bridge/libseekdb_cuvs_bridge.so'
    run('bridge-build',['bash','tools/hipvs_bridge/build.sh',bridge],timeout=300)
    stage='official-release-build';save()
    run('release-build',['bash','build.sh','release','-DOB_BUILD_CUVS=ON',
        '-DOB_BUILD_CUVS_TRACE=OFF','-DCUVS_BRIDGE_LIB='+str(bridge),'--make','-j4'])
    stage='verify-product-source';save()
    hashes=json.loads((EV/'source-sha256.json').read_text())
    for name,value in hashes.items():assert digest(SRC/name)==value,name
    report['tracked_files_unchanged']=len(hashes)
    run('source-diff',['git','diff','--exit-code'],timeout=60)
    report['bridge_sha256']=digest(bridge)
    binary=SRC/'build_release/src/observer/seekdb'
    report['binary_sha256']=digest(binary)
    version=subprocess.check_output([binary,'--version'],env=env,text=True,stderr=subprocess.STDOUT)
    (EV/'binary-version.txt').write_text(version);assert report['source_commit'] in version
    report['build_completed']=True
    stage='build-passed';report['completed']=True;save()
except Exception as error:
    report['error']=repr(error);stage='failed';save();traceback.print_exc();raise
