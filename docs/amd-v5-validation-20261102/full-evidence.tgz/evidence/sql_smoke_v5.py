from pathlib import Path
import json
import os
import subprocess
import time
import traceback
import numpy as np

ROOT=Path('/workspace/amd-v5-repair-20261102')
SRC=ROOT/'source';EV=ROOT/'evidence';DB=Path('/var/tmp/amd-v5-repair-20261102')
PORT='2901';binary=SRC/'build_release/src/observer/seekdb';bridge=ROOT/'bridge/libseekdb_cuvs_bridge.so'
env=dict(os.environ)
env.update(LD_LIBRARY_PATH=str(bridge.parent)+':/opt/hipvs/lib:/opt/rocm/lib',
           OMP_NUM_THREADS='8',OPENBLAS_NUM_THREADS='8')
report={'completed':False,'source_commit':'d4840ee3ea658250810883a63b299b428290d3c0',
        'scope':'V5 baseline eligibility and small SQL smoke; not formal 250K/4096 judging or a speedup claim',
        'datasets':[],'stage':'waiting-for-build'}
process=None


def save():
    report['updated_utc']=time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime())
    (EV/'sql-smoke.json').write_text(json.dumps(report,indent=2))
    print(json.dumps({'stage':report['stage'],'completed':report['completed']}),flush=True)


def sql(statement, timeout=180):
    p=subprocess.run(['mysql','--local-infile=1','-h127.0.0.1','-P'+PORT,'-uroot',
                      '-ANB','-e','set ob_query_timeout=600000000; '+statement],
                     env=env,text=True,capture_output=True,timeout=timeout)
    if p.returncode:
        raise RuntimeError('SQL failed: '+p.stderr[:2000])
    return p.stdout.strip()


def start():
    global process
    log=(EV/'server-console.log').open('a')
    args=[str(binary),'--nodaemon','--base-dir',str(DB),'--data-dir',str(DB/'store'),
          '--port',PORT,'--parameter','memory_budget=4G','--parameter','cpu_count=16',
          '--parameter','datafile_size=2G','--parameter','datafile_maxsize=8G',
          '--parameter','log_disk_size=2G','--parameter','local_ip=127.0.0.1',
          '--parameter','__min_full_resource_pool_memory=2147483648',
          '--parameter','syslog_level=INFO']
    process=subprocess.Popen(args,env=env,stdout=log,stderr=subprocess.STDOUT)
    deadline=time.monotonic()+240
    while time.monotonic()<deadline:
        if process.poll() is not None:raise RuntimeError('observer exited before SQL ready')
        try:
            if sql('select 1',timeout=5)=='1':return
        except (RuntimeError,subprocess.TimeoutExpired):pass
        time.sleep(1)
    raise TimeoutError('observer SQL startup timeout')


def stop():
    global process
    if process is not None and process.poll() is None:
        process.terminate()
        try:process.wait(timeout=30)
        except subprocess.TimeoutExpired:process.kill();process.wait(timeout=10)
    process=None


def query(table, vector, k):
    return [int(x) for x in sql(f"use v5_smoke; select id from {table} order by l2_distance(v,'{vector}') approximate limit {k}").splitlines()]


try:
    save();deadline=time.monotonic()+10800
    while True:
        state=json.loads((EV/'validation-status.json').read_text())
        if state.get('stage')=='failed':raise RuntimeError('build/provisioning failed: '+state.get('error',''))
        if state.get('build_completed'):break
        if time.monotonic()>deadline:raise TimeoutError('waiting for V5 build')
        time.sleep(10)
    assert not DB.exists(), 'refuse to reuse an existing smoke database directory'
    DB.mkdir();report['stage']='start-official-v5-observer';save();start()
    sql('create database v5_smoke')
    rng=np.random.default_rng(20261102)
    inputs=[('sift10k',np.fromfile('/seekdb_workspace/datasets/base.f32',dtype=np.float32).reshape(-1,128),
             np.fromfile('/seekdb_workspace/datasets/query.f32',dtype=np.float32).reshape(-1,128)[:64]),
            ('generated256',rng.normal(size=(10000,256)).astype(np.float32),rng.normal(size=(64,256)).astype(np.float32))]
    stored=[]
    for name,base,probes in inputs:
        report['stage']='sql-'+name;save();n,dim=base.shape
        ids=1000003+np.arange(n,dtype=np.int64)*7
        vectors=['['+','.join(format(float(v),'.9g') for v in row)+']' for row in base]
        qvectors=['['+','.join(format(float(v),'.9g') for v in row)+']' for row in probes]
        path=ROOT/(name+'.tsv')
        path.write_text(''.join(str(int(i))+'\t'+v+'\n' for i,v in zip(ids,vectors)))
        table='items_'+name
        sql(f"use v5_smoke; create table {table}(id bigint primary key,v vector({dim})); load data local infile '{path}' into table {table} fields terminated by '\\t' lines terminated by '\\n' (id,v)")
        assert int(sql('select count(*) from v5_smoke.'+table))==n
        begin=time.monotonic()
        sql(f'use v5_smoke; create vector index idx on {table}(v) with (distance=l2,type=hnsw,lib=cuvs,m=16,ef_construction=200,ef_search=64)')
        valid=set(map(int,ids));bf=base.astype(np.float64);qf=probes.astype(np.float64)
        distances=(bf*bf).sum(1)[None,:]+(qf*qf).sum(1)[:,None]-2*qf@bf.T
        truth=ids[np.argsort(distances,axis=1)[:,:100]]
        row={'name':name,'rows':n,'dimension':dim,'queries':len(probes),'topk':{},'ddl_seconds':time.monotonic()-begin}
        # Per-query SQL remains approximate CAGRA through lib=cuvs; assert the
        # output contract before computing recall. These are development data.
        for k in [10,100]:
            hits=0;all_results=[]
            for qi,vector in enumerate(qvectors):
                got=query(table,vector,k)
                assert len(got)==k and len(set(got))==k and set(got)<=valid
                hits+=len(set(got)&set(map(int,truth[qi,:k])));all_results.append(got)
            recall=hits/(len(probes)*k);assert recall>=0.75,(name,k,recall)
            row['topk'][str(k)]={'recall_at_k':recall,'complete_unique_legal_ids':True}
            (EV/(name+'-top'+str(k)+'-ids.json')).write_text(json.dumps(all_results))
        report['datasets'].append(row);stored.append((table,qvectors[0],valid,set(map(int,truth[0,:100]))));save()
    fds=[]
    for f in Path('/proc/'+str(process.pid)+'/fd').iterdir():
        try:fds.append(os.readlink(f))
        except OSError:pass
    report['gpu_device_fds']=[x for x in fds if x.startswith('/dev/kfd') or x.startswith('/dev/dri/')]
    assert any(x.startswith('/dev/kfd') for x in fds) and any('/dev/dri/renderD' in x for x in fds)
    sql('use v5_smoke; create table cpu_items(id bigint primary key,v vector(128)); insert into cpu_items select * from items_sift10k limit 1000; create vector index cpu_idx on cpu_items(v) with (distance=l2,type=hnsw,lib=vsag,m=16,ef_construction=200,ef_search=64)')
    assert len(set(query('cpu_items',stored[0][1],10)))==10
    report['cpu_vsag_basic_query']=True
    report['stage']='gpu-snapshot-restart';save();stop();start()
    report['restart']={}
    for table,vector,valid,truth in stored:
        got=query(table,vector,100)
        assert len(got)==100 and len(set(got))==100 and set(got)<=valid
        recall=len(set(got)&truth)/100;assert recall>=0.75
        report['restart'][table]={'recall_at_100':recall,'complete_unique_legal_ids':True}
    stop()
    events=[]
    for p in (DB/'log').glob('seekdb.log*'):
        with p.open(errors='replace') as f:
            events.extend(line for line in f if 'GPU CAGRA snapshot' in line)
    (EV/'snapshot-events.log').write_text(''.join(events))
    report['snapshot_events_captured']=len(events)
    assert any('deserialized GPU CAGRA snapshot' in line for line in events)
    report['completed']=True;report['stage']='passed';save()
except Exception as error:
    report['error']=repr(error);report['stage']='failed';save();traceback.print_exc();raise
finally:
    stop()
