#!/bin/bash
set -euo pipefail
cd /workspace/amd-v5-round2
tar -xzf source-git.tar.gz
mkdir -p frozen-100-w4 evidence
cp source/tools/hipvs_bridge/{seekdb_cuvs_bridge.c,seekdb_cuvs_bridge.h,build.sh} frozen-100-w4/
bash frozen-100-w4/build.sh "$PWD/frozen-100-w4/libseekdb_cuvs_bridge.so"
bash source/src/sql/parser/gen_type_name.sh source/src/query/api/query/parser/ob_item_type.h > source/src/sql/parser/type_name.c
/opt/venv/bin/python -m pip install 'PyMySQL==1.1.2'
exec /opt/venv/bin/python build_main.py
