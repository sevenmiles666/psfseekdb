from pathlib import Path
import json
import shutil
import subprocess
import sys
import time

root=Path('/workspace/amd-v5-round2');bench=root/'product/tools/hipvs_bridge/benchmarks'
for _ in range(240):
    if 'FINAL3_PRODUCT_BUILD_AND_TESTS_PASSED' in (root/'final3-build.log').read_text():break
    state=subprocess.check_output(['ps','-p','16962','-o','stat='],text=True).strip()
    if not state or state.startswith('Z'):raise RuntimeError('Final product build/tests failed')
    time.sleep(2)
else:raise RuntimeError('Final product preparation did not complete')
def logged(command,path):
    with path.open('w') as log:subprocess.run(command,stdout=log,stderr=subprocess.STDOUT,check=True)
logged([sys.executable,str(bench/'benchmark_bridge.py'),'--work-dir',str(root),'--prepare','sift10k'],root/'evidence/final3-quick-data.log')
stress=root/'seed-final3';stress.mkdir(exist_ok=False)
code=(bench/'benchmark_bridge.py').read_text()
assert code.count('default_rng(20261102)')==1
(stress/'benchmark_seed.py').write_text(code.replace('default_rng(20261102)','default_rng(20261103)'))
shutil.copyfile(bench/'gpu_monitor.py',stress/'gpu_monitor.py')
logged([sys.executable,str(stress/'benchmark_seed.py'),'--work-dir',str(stress),'--prepare','gaussian256'],root/'evidence/final3-independent-data.log')
for work,script,kind in [(root,bench/'benchmark_bridge.py','sift10k'),(root,bench/'benchmark_bridge.py','clustered256'),(stress,stress/'benchmark_seed.py','gaussian256')]:
    for label,lib in [('final3-baseline',root/'frozen-100-w4/libseekdb_cuvs_bridge.so'),('final3-selected',root/'final3-bridge/libseekdb_cuvs_bridge.so')]:
        logged([sys.executable,str(script),'--work-dir',str(work),'--dataset',kind,'--label',label,'--lib',str(lib),'--rounds','3'],root/'evidence'/f'quality-{work.name}-{kind}-{label}.log')
        record=json.loads((work/'evidence'/f'{kind}-{label}.json').read_text())
        assert record['completed']
    a=json.loads((work/'evidence'/f'{kind}-final3-baseline.json').read_text());b=json.loads((work/'evidence'/f'{kind}-final3-selected.json').read_text())
    checks={}
    for k in ('10','100'):
        floor=.75 if kind=='sift10k' else (.9 if k=='10' else .85)
        threshold=max(floor,max(r['topk'][k]['recall'] for r in a['rounds'])-.005)
        actual=min(r['topk'][k]['recall'] for r in b['rounds']);assert actual>=threshold
        checks[k]={'candidate_worst':actual,'threshold':threshold,'passed':True}
    assert b['peak_vram_device_bytes']<=45_000_000_000 and b['peak_vram_device_bytes']<=1.25*a['peak_vram_device_bytes']
    (root/'evidence'/f'final3-quality-{work.name}-{kind}.json').write_text(json.dumps(checks,indent=2))
    print('FINAL3_QUALITY_PASSED',work.name,kind,json.dumps(checks),flush=True)
# The same fixed backend is exercised through all 4096 ordinary SQL queries.
profiles=[('final3-sql-baseline-1','baseline-main','frozen-100-w4'),
          ('final3-sql-selected-1','final3-main','final3-bridge'),
          ('final3-sql-selected-2','final3-main','final3-bridge'),
          ('final3-sql-baseline-2','baseline-main','frozen-100-w4')]
for label,main,bridge in profiles:
    logged([sys.executable,str(bench/'benchmark_sql.py'),'--work-dir',str(root),'--binary',str(root/main/'seekdb'),'--bridge',str(root/bridge/'libseekdb_cuvs_bridge.so'),'--label',label,'--port','2902','--nq','4096'],root/'evidence'/f'sql-{label}.log')
    print('FINAL3_SQL_COMPLETED',label,flush=True)
for number in (1,2):
    logged([sys.executable,str(bench/'compare_sql4096.py'),'--baseline',str(root/'evidence'/f'sql-final3-sql-baseline-{number}.json'),'--candidate',str(root/'evidence'/f'sql-final3-sql-selected-{number}.json'),'--output',str(root/'evidence'/f'final3-sql-comparison-{number}.json')],root/'evidence'/f'final3-sql-comparison-{number}.log')
    report=json.loads((root/'evidence'/f'final3-sql-comparison-{number}.json').read_text())
    print('FINAL3_SQL_COMPARISON',number,report['combined_build_ratio'],report['combined_query_ratio'],report['proxy_score'],flush=True)
print('FINAL3_VALIDATION_FINISHED',flush=True)
