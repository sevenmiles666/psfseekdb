"""Preserve only source, logs, metadata and returned IDs from the final run."""
from datetime import datetime, timezone
from pathlib import Path
import hashlib
import json
import subprocess
import tarfile

ROOT = Path('/workspace/amd-v5-round2')
OUT = ROOT / 'final3-evidence'


def sha(path):
    digest = hashlib.sha256()
    with path.open('rb') as source:
        for block in iter(lambda: source.read(8 << 20), b''):
            digest.update(block)
    return digest.hexdigest()


def write_json(path, value):
    path.write_text(json.dumps(value, indent=2, allow_nan=False) + '\n')


def capture(command):
    result = subprocess.run(command, stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                            text=True, check=False)
    return {'command': command, 'exit_code': result.returncode, 'output': result.stdout}


def main():
    markers = [('final3-build.log', 'FINAL3_PRODUCT_BUILD_AND_TESTS_PASSED'),
               ('final3-validation.log', 'FINAL3_VALIDATION_FINISHED'),
               ('final3-backend-trace.log', 'FINAL3_GPU_PATH_VERIFIED'),
               ('final3-normalized.log', 'FINAL3_NORMALIZED_CHECK_FINISHED')]
    for name, marker in markers:
        assert marker in (ROOT / name).read_text(), name
    OUT.mkdir(exist_ok=False)
    entries = {}

    def add(path, name):
        path = path.resolve()
        assert path.is_relative_to(ROOT.resolve()) and path.is_file()
        assert not path.is_symlink()
        assert name not in entries
        assert path.suffix in ('.py', '.sh', '.c', '.h', '.cpp', '.json', '.txt', '.log', '.npy')
        if path.suffix == '.npy':
            assert '-ids' in path.name
        entries[name] = path

    source_hashes = json.loads((ROOT / 'product/source-hashes.json').read_text())
    for name, digest in source_hashes.items():
        path = ROOT / 'product' / name
        assert sha(path) == digest, name
        add(path, 'product/' + name)
    add(ROOT / 'product/source-hashes.json', 'source-hashes.json')
    for name in ('seekdb_cuvs_bridge.c', 'seekdb_cuvs_bridge.h', 'build.sh'):
        add(ROOT / 'frozen-100-w4' / name, 'baseline/' + name)
    for name in ('final_build.py', 'final_verify.py', 'final_backend_trace.py',
                 'final_normalized_quality.py', 'collect_final.py', 'build_main.py',
                 'resume_build.sh', 'bootstrap.sh', 'prepare_sql_and_mains_resume.py',
                 'sql_screen.py', 'summarize_sql.py', 'test_fast_graph_sql.py'):
        add(ROOT / name, 'drivers/' + name)
    for name in ('final3-build.log', 'final3-main-build.log', 'final3-validation.log',
                 'final3-backend-trace.log', 'final3-normalized.log',
                 'stage2-build.log', 'stage2-build-resume.log',
                 'stage2-sql-screen.json', 'stage2-fast-graph-sql.json',
                 'stage2-search-modes.json', 'stage2-smaller-graphs.json'):
        add(ROOT / name, 'logs/' + name)
    for work in (ROOT, ROOT / 'seed-final3', ROOT / 'normalized-final3'):
        prefix = '' if work == ROOT else work.name + '/'
        for path in sorted((work / 'evidence').iterdir()):
            if 'final3' in path.name and path.suffix in ('.json', '.log', '.txt', '.npy'):
                add(path, prefix + 'evidence/' + path.name)
        for path in sorted((work / 'data').glob('*/dataset.json')):
            add(path, prefix + 'data/' + path.parent.name + '/dataset.json')
    for name in ('benchmark_seed.py', 'gpu_monitor.py'):
        add(ROOT / 'seed-final3' / name, 'seed-final3/' + name)
    for name in ('benchmark_normalized.py', 'gpu_monitor.py'):
        add(ROOT / 'normalized-final3' / name, 'normalized-final3/' + name)
    add(ROOT / 'final3-trace-bridge/seekdb_cuvs_bridge.c', 'diagnostic/seekdb_cuvs_bridge.c')

    comparisons = [json.loads((ROOT / 'evidence' / f'final3-sql-comparison-{n}.json').read_text())
                   for n in (1, 2)]
    assert all(row['passed'] for row in comparisons)
    trace = json.loads((ROOT / 'evidence/final3-gpu-path-summary.json').read_text())
    normalized = json.loads((ROOT / 'evidence/final3-normalized-quality.json').read_text())
    environment = {
        name: capture(command) for name, command in {
            'kernel': ['uname', '-a'], 'gpu': ['rocm-smi', '--showbus', '--json'],
            'hip': ['/opt/rocm/bin/hipcc', '--version'],
            'cpu_quota': ['cat', '/sys/fs/cgroup/cpu.max'],
            'memory_quota': ['cat', '/sys/fs/cgroup/memory.max'],
            'memory_events': ['cat', '/sys/fs/cgroup/memory.events'],
            'python': ['/opt/venv/bin/python', '-c',
                       'import sys,numpy,pymysql;print(sys.version);print(numpy.__version__);print(pymysql.__version__)'],
            'restored_source_head': ['git', '-C', str(ROOT / 'source'), 'rev-parse', 'HEAD'],
        }.items()
    }
    write_json(OUT / 'environment.json', environment)
    binaries = {name: sha(ROOT / path) for name, path in {
        'baseline_main': 'baseline-main/seekdb', 'candidate_main': 'final3-main/seekdb',
        'baseline_bridge': 'frozen-100-w4/libseekdb_cuvs_bridge.so',
        'candidate_bridge': 'final3-bridge/libseekdb_cuvs_bridge.so',
        'instrumented_diagnostic_bridge': 'final3-trace-bridge/libseekdb_cuvs_bridge.so',
    }.items()}
    execution = {
        'scope': 'Development validation on public SIFT and generated 256D samples; not official Hidden',
        'created_utc': datetime.now(timezone.utc).isoformat(),
        'frozen_v5_commit': '634888d9b037153fa143d2c913ba4b25503e1d62',
        'parent_commit': 'b775ded989531f42f4a3b700aa713971fb1912d3',
        'parent_official_score_user_reported': 8.9,
        'source_sha256': source_hashes, 'binary_sha256': binaries,
        'baseline_source_sha256': {name: sha(ROOT / 'frozen-100-w4' / name)
                                   for name in ('seekdb_cuvs_bridge.c', 'seekdb_cuvs_bridge.h', 'build.sh')},
        'sql_pairs': comparisons, 'gpu_path_diagnostic': trace,
        'normalized_distribution': normalized,
        'official_score': None, 'all_official_gates_verified': False,
        'archive_excludes': ['executables', 'shared objects', 'database directories',
                             'vector/query/truth data', 'index snapshots', 'credentials'],
    }
    write_json(OUT / 'execution.json', execution)
    add(OUT / 'environment.json', 'environment.json')
    add(OUT / 'execution.json', 'execution.json')
    manifest = {name: {'bytes': path.stat().st_size, 'sha256': sha(path)}
                for name, path in sorted(entries.items())}
    write_json(OUT / 'manifest.json', manifest)
    add(OUT / 'manifest.json', 'manifest.json')
    archive_path = OUT / 'full-evidence.tgz'
    with tarfile.open(archive_path, 'w:gz', compresslevel=6) as archive:
        for name, path in sorted(entries.items()):
            archive.add(path, arcname=name, recursive=False)
    digest = sha(archive_path)
    (OUT / 'full-evidence.tgz.sha256').write_text(digest + '  full-evidence.tgz\n')
    print(json.dumps({'archive': str(archive_path), 'bytes': archive_path.stat().st_size,
                      'sha256': digest, 'files': len(entries)}, indent=2), flush=True)


if __name__ == '__main__':
    main()
