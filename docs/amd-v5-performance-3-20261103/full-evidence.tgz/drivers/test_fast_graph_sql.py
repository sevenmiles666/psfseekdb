from pathlib import Path
import json
import subprocess
import sys

root=Path('/workspace/amd-v5-round2')
results=[]
for name in ('stage2-g64-i64-k4096','stage2-g96-i128-k2048'):
    label='stage2-sql-'+name.removeprefix('stage2-')+'-256'
    with (root/'evidence'/('sql-'+label+'.log')).open('w') as log:
        subprocess.run([sys.executable,str(root/'benchmark_sql_complete.py'),'--work-dir',str(root),'--binary',str(root/'worker-main/seekdb'),'--bridge',str(root/name/'libseekdb_cuvs_bridge.so'),'--label',label,'--port','2902','--nq','256'],stdout=log,stderr=subprocess.STDOUT,check=True)
    result=json.loads((root/'evidence'/('sql-'+label+'.json')).read_text())
    results.append(result);(root/'stage2-fast-graph-sql.json').write_text(json.dumps(results,indent=2));print(json.dumps(result),flush=True)
print('FAST_GRAPH_SQL_COMPLETED',flush=True)
