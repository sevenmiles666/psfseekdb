from pathlib import Path
import json
import shutil
import subprocess
import sys
import time

root=Path('/workspace/amd-v5-round2');bench=root/'product/tools/hipvs_bridge/benchmarks'
for _ in range(1200):
    if 'FINAL3_GPU_PATH_VERIFIED' in (root/'final3-backend-trace.log').read_text():break
    time.sleep(2)
else:raise RuntimeError('Backend call-path verification did not complete')
work=root/'normalized-final3';work.mkdir(exist_ok=False)
source=(bench/'benchmark_bridge.py').read_text().replace('default_rng(20261102)','default_rng(20261104)')
old='        queries = rng.normal(size=(4096,256)).astype(np.float32)'
assert source.count(old)==1
source=source.replace(old,old+'\n        base /= np.linalg.norm(base,axis=1,keepdims=True)\n        queries /= np.linalg.norm(queries,axis=1,keepdims=True)')
source=source.replace("    (dest/'dataset.json').write_text(json.dumps(meta,indent=2))", "    meta['distribution']='unit-normalized Gaussian, seed 20261104'\n    (dest/'dataset.json').write_text(json.dumps(meta,indent=2))")
(work/'benchmark_normalized.py').write_text(source)
shutil.copyfile(bench/'gpu_monitor.py',work/'gpu_monitor.py')
with (root/'evidence/final3-normalized-data.log').open('w') as log:
    subprocess.run([sys.executable,str(work/'benchmark_normalized.py'),'--work-dir',str(work),'--prepare','gaussian256'],stdout=log,stderr=subprocess.STDOUT,check=True)
for label,lib in [('final3-normalized-baseline',root/'frozen-100-w4/libseekdb_cuvs_bridge.so'),('final3-normalized-selected',root/'final3-bridge/libseekdb_cuvs_bridge.so')]:
    with (root/'evidence'/f'{label}.log').open('w') as log:
        subprocess.run([sys.executable,str(work/'benchmark_normalized.py'),'--work-dir',str(work),'--dataset','gaussian256','--label',label,'--lib',str(lib),'--rounds','3'],stdout=log,stderr=subprocess.STDOUT,check=True)
a=json.loads((work/'evidence/gaussian256-final3-normalized-baseline.json').read_text());b=json.loads((work/'evidence/gaussian256-final3-normalized-selected.json').read_text())
report={'scope':'additional generated unit-norm distribution, not official Hidden','checks':{}}
for k in ('10','100'):
    baseline=max(r['topk'][k]['recall'] for r in a['rounds']);candidate=min(r['topk'][k]['recall'] for r in b['rounds'])
    floor=.9 if k=='10' else .85;threshold=max(floor,baseline-.005)
    report['checks'][k]={'baseline_best':baseline,'candidate_worst':candidate,'threshold':threshold,'passed':candidate>=threshold,'baseline_above_absolute_floor':baseline>=floor}
report['passed']=all(check['passed'] for check in report['checks'].values())
(root/'evidence/final3-normalized-quality.json').write_text(json.dumps(report,indent=2))
print(json.dumps(report,indent=2),flush=True)
print('FINAL3_NORMALIZED_CHECK_FINISHED',flush=True)
