from collections import Counter
from pathlib import Path
import json
import subprocess
import sys
import time

root=Path('/workspace/amd-v5-round2');tool=root/'product/tools/hipvs_bridge'
for _ in range(900):
    if 'FINAL3_VALIDATION_FINISHED' in (root/'final3-validation.log').read_text():break
    time.sleep(2)
else:raise RuntimeError('Paired validation did not complete')
dest=root/'final3-trace-bridge';dest.mkdir(exist_ok=False)
source=(tool/'seekdb_cuvs_bridge.c').read_text()
helper='''
#include <fcntl.h>
#include <unistd.h>
#include <hip/hip_runtime.h>
static void profile_gpu(const char* event,long n,long dim,long nq,long k,int rc) {
  int device=-1;char pci[64]={0};
  hipGetDevice(&device);hipDeviceGetPCIBusId(pci,sizeof(pci),device);
  int fd=open("/workspace/amd-v5-round2/evidence/final3-gpu-events.log",O_WRONLY|O_CREAT|O_APPEND|O_CLOEXEC,0600);
  if(fd>=0){dprintf(fd,"pid=%d event=%s n=%ld dim=%ld nq=%ld k=%ld rc=%d device=%d pci=%s\\n",getpid(),event,n,dim,nq,k,rc,device,pci);close(fd);}
}
'''
source=source.replace('#include <stdlib.h>','#include <stdlib.h>\n'+helper)
source=source.replace('  h->n = n; h->dim = dim;\n  return h;','  h->n = n; h->dim = dim;\n  profile_gpu("build",n,dim,0,0,0);\n  return h;')
source=source.replace('  pthread_mutex_unlock(&h->search_mutex);\n  return rc;','  profile_gpu("search",h->n,h->dim,nq,topk,rc);\n  pthread_mutex_unlock(&h->search_mutex);\n  return rc;')
source=source.replace('  index->n = n;\n  index->dim = dim;\n  return index;','  index->n = n;\n  index->dim = dim;\n  profile_gpu("deserialize",n,dim,0,0,0);\n  return index;')
(dest/'seekdb_cuvs_bridge.c').write_text(source)
for name in ('seekdb_cuvs_bridge.h','build.sh'):(dest/name).write_bytes((tool/name).read_bytes())
subprocess.run(['bash',str(dest/'build.sh'),str(dest/'libseekdb_cuvs_bridge.so')],check=True)
with (root/'evidence/sql-final3-backend-trace.log').open('w') as log:
    subprocess.run([sys.executable,str(tool/'benchmarks/benchmark_sql.py'),'--work-dir',str(root),'--binary',str(root/'final3-main/seekdb'),'--bridge',str(dest/'libseekdb_cuvs_bridge.so'),'--label','final3-backend-trace','--port','2902','--nq','4096'],stdout=log,stderr=subprocess.STDOUT,check=True)
events=[dict(field.split('=',1) for field in row.split()) for row in (root/'evidence/final3-gpu-events.log').read_text().splitlines()]
queries=[event for event in events if event['event']=='search']
assert all(event['rc']=='0' and event['n']=='250000' and event['nq']=='1' for event in queries)
counts=Counter((event['dim'],event['k']) for event in queries)
assert all(counts[(dim,k)]>=8192 for dim in ('128','256') for k in ('10','100'))
record=json.loads((root/'evidence/sql-final3-backend-trace.json').read_text())
assert {event['pci'].lower() for event in events}=={record['gpu_pci_bus']}
report={'scope':'instrumented development diagnostic, excluded from performance comparisons',
        'completed':True,'all_gpu_searches_successful':True,'search_calls':len(queries),
        'counts':{dim+'-top'+k:value for (dim,k),value in sorted(counts.items())},
        'gpu_pci_bus':record['gpu_pci_bus'],'counter_matches_actual_gpu':True,
        'builds':len([event for event in events if event['event']=='build']),
        'deserializations':len([event for event in events if event['event']=='deserialize'])}
(root/'evidence/final3-gpu-path-summary.json').write_text(json.dumps(report,indent=2))
print(json.dumps(report,indent=2),flush=True)
print('FINAL3_GPU_PATH_VERIFIED',flush=True)
