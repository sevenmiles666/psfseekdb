from pathlib import Path
import json
import subprocess
import sys
import time

root=Path('/workspace/amd-v5-round2')
for _ in range(240):
    if 'MORE_MCTA_COMPLETED' in (root/'stage2-more-mcta.log').read_text() and 'STAGE2_MAINS_READY' in (root/'stage2-mains-resume.log').read_text():break
    time.sleep(2)
else:raise RuntimeError('Candidate preparation has not completed; refusing concurrent GPU timings')
profiles=[('frozen','baseline-main','frozen-100-w4'),('current','baseline-main','release-selected'),
          ('workspace','baseline-main','workspace-reuse'),('worker-current','worker-main','release-selected'),
          ('worker-mcta8','worker-main','stage2-mcta8'),('worker-mcta8pool','worker-main','stage2-mcta8-pool'),
          ('worker-mcta4','worker-main','stage2-mcta4')]
records=[]
for tag,main,bridge in profiles:
    label='stage2-sql-'+tag+'-256'
    with (root/'evidence'/('sql-'+label+'.log')).open('w') as log:
        rc=subprocess.run([sys.executable,str(root/'benchmark_sql_complete.py'),'--work-dir',str(root),'--binary',str(root/main/'seekdb'),'--bridge',str(root/bridge/'libseekdb_cuvs_bridge.so'),'--label',label,'--port','2902','--nq','256'],stdout=log,stderr=subprocess.STDOUT).returncode
    result=json.loads((root/'evidence'/('sql-'+label+'.json')).read_text())
    records.append(result);(root/'stage2-sql-screen.json').write_text(json.dumps(records,indent=2))
    print('SQL_SCREEN_RESULT',label,rc,json.dumps(result),flush=True)
    if rc:raise RuntimeError('SQL candidate failed: '+label)
print('SQL_SCREEN_COMPLETED',flush=True)
