from pathlib import Path
import json
import math

root=Path('/workspace/amd-v5-round2')
records=json.loads((root/'stage2-sql-screen.json').read_text())
if (root/'stage2-fast-graph-sql.json').exists():records+=json.loads((root/'stage2-fast-graph-sql.json').read_text())
base={r['name']:r for r in records[0]['datasets']}
for record in records[1:]:
    B=Q=1.;quality=True;details=[]
    for row in record['datasets']:
        a=base[row['name']];b=a['ddl_plus_first_query_seconds']/row['ddl_plus_first_query_seconds']
        q=math.sqrt(math.prod(row['topk'][k]['qps']/a['topk'][k]['qps'] for k in ('10','100')))
        weight=.4 if row['dim']==128 else .6;B*=b**weight;Q*=q**weight
        for k in ('10','100'):
            floor=.95 if row['dim']==128 else (.9 if k=='10' else .85)
            quality=quality and row['topk'][k]['recall']>=max(floor,a['topk'][k]['recall']-.005)
        details.append((row['name'],round(row['ddl_plus_first_query_seconds'],4),round(b,4),round(q,4)))
    vram=record['peak_vram_device_bytes']/records[0]['peak_vram_device_bytes']
    print(json.dumps({'label':record['label'],'scope':'256-query screening only','B':B,'Q':Q,'quality_passed':quality,'vram_ratio':vram,'details':details}),flush=True)
