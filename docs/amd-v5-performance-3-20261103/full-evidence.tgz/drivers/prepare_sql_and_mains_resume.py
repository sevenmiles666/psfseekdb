from pathlib import Path
import subprocess
import os
import sys
import time

root=Path('/workspace/amd-v5-round2')
source=(root/'benchmark_sql.py').read_text()
source=source.replace("'scope':'real cold SQL DDL through first legal query; unchanged V5 main executable, candidate bridge rebuilt from source'", "'scope':'complete SQL query-set development run; nq counts individual SQL queries, not one CAGRA batch; binary and bridge identified by SHA-256'")
source=source.replace("    proc=None;conn=None", "    proc=None;conn=None\n    evaluation_begin=time.monotonic()")
source=source.replace("            if not data_file.exists():", "            provenance=dest/'vectors.tsv.provenance.json'\n            expected={'base_sha256':sha(dest/'base.npy'),'rows':len(base),'dim':base.shape[1],'id_mapping':'1000003+row*7','float_format':'.9g'}\n            if not data_file.exists() or not provenance.exists() or json.loads(provenance.read_text())!=expected:")
source=source.replace("            table='items_'+kind", "                provenance.write_text(json.dumps(expected,indent=2))\n            table='items_'+kind")
source=source.replace("            build=time.perf_counter()-begin", "            build=time.perf_counter()-begin\n            valid=set(map(int,ids))\n            assert len(first)==10 and len(set(first))==10 and all(i in valid for i in first), 'First timed query must return 10 legal unique IDs'")
source=source.replace("        report['reload_validated']=True;report['completed']=True;save()", "        report['gpu_evaluation_seconds']=time.monotonic()-evaluation_begin\n        report['reload_validated']=True;report['completed']=True;save()")
(root/'benchmark_sql_complete.py').write_text(source)
# Preserve the first, unchanged main before building the worker candidate.
for _ in range(240):
    log=(root/'stage2-build-resume.log').read_text(errors='replace')
    if 'FULL_V5_BUILD_COMPLETED' in log:break
    state=subprocess.check_output(['ps','-p','6643','-o','stat='],text=True).strip()
    if not state or state.startswith('Z'):raise RuntimeError('V5 build failed; inspect stage2-build.log')
    time.sleep(5)
else:raise RuntimeError('V5 build has not completed')
baseline=root/'baseline-main';baseline.mkdir(exist_ok=False)
binary=root/'source/build_release/src/observer/seekdb'
subprocess.run(['cp','--reflink=auto',str(binary),str(baseline/'seekdb')],check=True)
# Use file-based tracing to establish the real built V5 SQL call path.
with (root/'evidence/sql-stage2-v5-trace.log').open('w') as log:
    subprocess.run([sys.executable,str(root/'benchmark_sql_complete.py'),'--work-dir',str(root),'--binary',str(baseline/'seekdb'),'--bridge',str(root/'stage2-file-trace/libseekdb_cuvs_bridge.so'),'--label','stage2-v5-trace','--port','2902','--nq','32'],stdout=log,stderr=subprocess.STDOUT,check=True)
print('V5_SQL_TRACE_COMPLETED',flush=True)
for name in ('cuvs_job_executor.h','ob_vsag_adaptor.cpp'):
    (root/'source/src/oblib/lib/vector'/name).write_bytes((root/'worker-reuse'/name).read_bytes())
env=dict(os.environ,CARGO_HOME=str(root/'tooling/cargo-home'),CARGO_NET_OFFLINE='true',CARGO_BUILD_JOBS='1',PATH='/opt/venv/bin:/opt/rocm/bin:/usr/local/bin:/usr/bin:/bin')
with (root/'stage2-worker-build.log').open('w') as log:
    subprocess.run(['bash','build.sh','release','-DOB_BUILD_CUVS=ON','-DOB_BUILD_CUVS_TRACE=OFF','-DCUVS_BRIDGE_LIB='+str(root/'frozen-100-w4/libseekdb_cuvs_bridge.so'),'--make','-j4'],cwd=root/'source',env=env,stdout=log,stderr=subprocess.STDOUT,check=True)
worker=root/'worker-main';worker.mkdir(exist_ok=False)
subprocess.run(['cp','--reflink=auto',str(binary),str(worker/'seekdb')],check=True)
print('STAGE2_MAINS_READY',flush=True)
