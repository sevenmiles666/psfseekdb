# seekdb × hipVS Notebook 展示包

先阅读 notebooks/seekdb-hipvs-batch-demo/README.md。
本包包含七章 Notebook、已执行输出、辅助代码和回归测试。
在课程 seekdb-hipvs Linux 镜像中，进入 notebooks/seekdb-hipvs-batch-demo 后运行 python run_demo.py。
依赖镜像内 /seekdb_workspace 的批量查询二进制、bridge、数据集及 AMD ROCm；不包含这些第三方大文件。
不需要模型 API Key。本次查询演示与主仓库的 HNSW 构建实验分别记录。
无 GPU 可核对 Notebook 输出、源码/结果 SHA-256，并从包根目录运行：
python -m unittest discover -s unittest/sql/vector_index -p 'test_batch_demo.py' -v
